/*
 Escribir unha clase Java que defina unha clase Lampada coas seguintes características:

- Ten un consumo en Watios, que é un número enteiro entre 0 e 250
- Ten unha luminosidade máxima en lúmenes, que é un número entre 0 e 100.000
- Ten unha luminosidade mínima en lúmenes que é un número entre 1 e 100.000
- A luminosidade actual da lámpada en lúmenes
- As lámpadas desta clase deben poder:

- Encenderse. Cando se encenden, se poñen a luminosidade mínima e visualizan unha mensaxe
indicando que están encendida e a luminosidade entre paréntese ( On(1) )
- Apagarse. Cando se apagan, se poñen a luminosidade 0 e visualizan unha mensaxe indicando
que están apagadas (Off())
- Cambiar a luminosidade indicando a luminosidade desexada, e si é admisible pola lámpada
se establecerá e se visualizará unha mensaxe On(luminosidade actual).
Si a lámpada está apagada, non ten efecto.
- Incrementar/Decrementar a luminosidade indicando o incremento/decremento desexado mediante 
un número positivo ou negativo. Se visualizará unha mensaxe  On (luminosidade actual). 
Si a lámpada está apagada, non ten efecto.
 */
package tarefa.pkg01.ud.pkg3;

/**
 *
 * @author xavi
 */
public class Lampada {
    private int maxlumens;
    private int minlumens;
    private int consumo;
    private int lumens;
    
    /** Constructor
     */
    public Lampada(int max,int min,int consumo) {
        this.maxlumens=max;
        this.minlumens=min;
        this.consumo=consumo;
        this.lumens=0;  // Inicialmente apagada
    }
    
    // Encende
    public String On() {
        this.lumens=minlumens;
        // Poderíamos visualizar aquí a mensaxe, pero así é mais útil.
        return "Encendida: "+getStatus();
    }
    
    // Apaga
    public String Off() {
        this.lumens=0;
        return "Apagada: "+getStatus();
    }
    
    // Cambia luminosidade
    public String set(int nlumens) throws Exception {
        if (nlumens > maxlumens) throw new Exception("Luminosidade Excesiva");
        this.lumens=nlumens;
        return getStatus();
    }
    
    // Aumenta/Disminúe a luminosidade
    public String controlLumen(int howmuch) throws Exception {
        int newlumen;
        
        if (lumens>0) {
            newlumen=lumens+howmuch;
            if ((newlumen > maxlumens) || (newlumen < 1)) throw new Exception("Luminosidade Excesiva");
            lumens=newlumen;
        }
        return getStatus();
    }
    
    /**
     * Non é necesaria segundo o enunciado, pero resulta útil
     * @return 
     */
    public String getStatus() {
        if (lumens>0) return "On("+this.lumens+")";
        return "Off()";
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Codigo de proba....
        Lampada l=new Lampada(120000,5,15);
        
        System.out.println(l.On()); // Encendido
        // Subimos 500000, a lampada so soporta 120000
        try {
            System.out.println(l.set(500000));
        } catch(Exception e) {
            System.out.println("ERROR:"+e.getMessage());
        }
        // Poñemos a luminosidade a 2, o mínimo e 5
        try {
            System.out.println(l.set(2));
        } catch(Exception e) {
            System.out.println("ERROR:"+e.getMessage());
        }
        // Poñemos a luminosidade a 10
        try {
            System.out.println(l.set(10));
        } catch(Exception e) {
            System.out.println("ERROR:"+e.getMessage());
        }
        // Baixamos en 10 a luminosidade (como o mínimo é 5, e está a 10...)
        try {
            System.out.println(l.controlLumen(-10));
        } catch(Exception e) {
            System.out.println("ERROR:"+e.getMessage());
        }
        // Baixamos a luminosidade en 1... será 9
        try {
            System.out.println(l.controlLumen(-1));
        } catch(Exception e) {
            System.out.println("ERROR:"+e.getMessage());
        }
        // Subimos a luminosidade en 200000, o máximo é 120000
        try {
            System.out.println(l.controlLumen(200000));
        } catch(Exception e) {
            System.out.println("ERROR:"+e.getMessage());
        }
        // Subimos a luminosidade en 4, será 13
        try {
            System.out.println(l.controlLumen(4));
        } catch(Exception e) {
            System.out.println("ERROR:"+e.getMessage());
        }
        System.out.println(l.Off());
    }
    
}
