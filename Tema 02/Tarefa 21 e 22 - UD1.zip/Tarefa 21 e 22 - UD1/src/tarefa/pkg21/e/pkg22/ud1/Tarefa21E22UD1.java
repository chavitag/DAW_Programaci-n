/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarefa.pkg21.e.pkg22.ud1;

import java.util.Arrays;

/**
 *
 * @author xavi
 */
public class Tarefa21E22UD1 {
    private int[][] board=new int[8][8];
    
    // Tarefa 21 - 01
    //
    void fill0() {
        for(int idx=0;idx<8;idx++) Arrays.fill(board[idx],0);
    }
    
    // Tarefa 21 - 02
    //
    // Pon a partir de f,c o valor val un máximo de numv veces
    void diagonal(int f,int c,int val,int numv) {
        while ((f<8) && (c<8) && (numv>0)) {
            board[f][c]=val;
            f++;
            c++;
            numv--;
        }
    }
    
    // Tarefa 21 - 03
    //
    public int countNearOne() {
        int cta=0;
        for(int f=0;f<board.length;f++)
            for(int c=0;c<board[f].length;c++)
                if (hasNearOne(f,c)) cta++;
        return cta;
    }
    
    /** Tarefa 22 
     * 
     */
    public int reverse(int f,int c) {
        int[][] dirs={{1,1},{-1,-1},{1,-1},{-1,1},{0,1},{0,-1},{1,0},{-1,0}};
        int cta=0;
        for(int idx=0;idx<dirs.length;idx++) cta+=test(f,c,dirs[idx][0],dirs[idx][1]);
        return cta;
    }
    
    // Sobrepoño toString para visualizar o taboleiro
    @Override
    public String toString() {
        String str="\n\n";
        for(int f=0;f<board.length;f++) {
            for(int c=0;c<board[f].length;c++) {
                str+=Integer.toString(board[f][c]);
            }
            str+="\n";
        }
        str+="\n";
        return str;
    }
    
    // Devolve true si a cela f,c ten algún 1 ao redor
    private boolean hasNearOne(int f,int c) {
        if (board[f][c]==0) {
            if ((c>0)&&(board[f][c-1]==1)) return true;
            if ((c<7)&&(board[f][c+1]==1)) return true;
            if (f>0) {
                if ((c>0)&&(board[f-1][c-1]==1)) return true;
                if (board[f-1][c]==1) return true;
                if ((c<7)&&(board[f-1][c+1]==1)) return true;
            }
            if (f<7) {
                if ((c>0)&&(board[f+1][c-1]==1)) return true;
                if (board[f+1][c]==1) return true;
                if ((c<7)&&(board[f+1][c+1]==1)) return true;
            }
        }
        return false;          
    }
    
    // Copia os valores de taboa en board
    private void setBoard(int[][] taboa) {
        for(int f=0;f<board.length;f++)
            for(int c=0;c<board[f].length;c++)
                board[f][c]=taboa[f][c];
    }
    
    /**
     * Pon a 1 numc celas dende f,c  na dirección indicada por drow,dcolumn
     * @param f
     * @param c
     * @param numc
     * @param drow
     * @param dcolumn
     */
    private void setToOne(int f,int c,int numc,int drow, int dcolumn) {
        while(numc>0) {
            board[f][c]=1;
            f+=drow;
            c+=dcolumn;
            numc--;
        }
    }
    
    /**
     * Comproba cantos 2 "atraparía" si en fil,col poñemos un 1 na dirección indicada
     * e lles da a volta
     * @param fil
     * @param col
     * @param drow  --> Direccíón das filas (0,1,-1)
     * @param dcolumn --> Dirección das columnas (0,1,-1)
     * @return 
     */
    private int test(int fil,int col,int drow,int dcolumn) {
        int r=fil+drow; 		// Comezamos na posición seguinte a que miramos
        int c=col+dcolumn;
        int cta=0;
        if ((c>=0)&&(c<8)&&(r>=0)&&(r<8)) {
            if (board[fil][col]!=0) return 0;
        
            while((r>=0)&&(r<8)&&(c>=0)&&(c<8)&&(board[r][c]==2)) {   // Mentras non sexa igual que a Piece que estamos poñendo....
                cta++;				// Contamos
                r+=drow; 			// Avanzamos na dirección indicada
                c+=dcolumn;
            }
            if (((r<0)||(r>7)||(c<0)||(c>7))||(board[r][c]!=1)) cta=0; // Si non atopamos o 2, cta é 0
            else {
                setToOne(r-drow,c-dcolumn,cta,-drow,-dcolumn); // Poñemos a 1
            }
        }
        return cta;
    }
    
  
    /**
     * TESTS de funcionamento...
     */
    public static void main(String[] args) throws Exception {
        Tarefa21E22UD1 tf=new Tarefa21E22UD1();
        // Poño unha taboa para facer os tests..
        int[][] taboa={ {0,0,1,0,2,0,0,1},
                        {0,0,0,2,1,1,0,2},
                        {0,1,1,2,0,1,0,1},
                        {0,2,0,2,1,2,0,2},
                        {0,1,1,0,2,0,2,0},
                        {0,2,2,0,2,1,2,1},
                        {2,0,0,1,0,2,2,2},
                        {0,0,0,0,0,0,0,0} };
        tf.setBoard(taboa);
        System.out.println("\n----------\nTest de Tarefa 21 - 01 ");
        System.out.println("Estado do taboleiro: "+tf);
        tf.fill0();
        System.out.println("Despois de fill0: "+tf);
        tf.setBoard(taboa);
        System.out.println("\n----------\nTest de Tarefa 21 - 02 ");
        System.out.println("Estado do taboleiro: "+tf);
        tf.diagonal(2,2,9,5);
        System.out.println("Despois de poñer 5 celas a 9 en diagonal dende 2,2 "+tf);
        tf.diagonal(0,5,9,9);
        System.out.println("Despois de intentar poñer 9 celas a 9 en diagonal dende 0,5 "+tf);
        System.out.println("\n----------\nTest de Tarefa 21 - 03 ");
        System.out.println("Existen "+tf.countNearOne()+" celas con polo menos un 1 ao redor");
        tf.setBoard(taboa); // Inicializamos
        System.out.println("\n----------\nTest de Tarefa 22 ");
        System.out.println("Estado do taboleiro: "+tf);
        System.out.println("Test (0,2): "+tf.reverse(0,2)+" celas. Taboleiro resultante: "+tf);
        System.out.println("Test (0,4): "+tf.reverse(0,4)+" celas. Taboleiro resultante: "+tf);
        System.out.println("Test (0,0): "+tf.reverse(0,0)+" celas. Taboleiro resultante: "+tf);
        System.out.println("Test (2,4): "+tf.reverse(2,4)+" celas. Taboleiro resultante: "+tf);
        System.out.println("Test (5,3): "+tf.reverse(5,3)+" celas. Taboleiro resultante: "+tf);
        System.out.println("Test (7,5): "+tf.reverse(7,5)+" celas. Taboleiro resultante: "+tf);

    }
}
