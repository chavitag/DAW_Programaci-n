/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package othello;

import java.io.IOException;

/**
 *
 * @author xavi
 */
public class RunGame {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Player p1=new Player("Xogador 1");
        Player p2=new Player("Xogador 2");
        Game g=new Game(p1,p2);
        g.runGame();
    }
    
}
