/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package othello;

/**
 *
 * @author xavi
 */
class Position {
    private int row;
    private int column;
    
    public Position(int row,char column) throws Exception {
        // Constructor da forma (1,’A’). Transformamos a coordenadas dende 0 .. n.
        // si row é 0, é un error... lanzamos unha Excepción
        if (row<=0) throw new Exception("Bad Row");
        this.row=row-1;
        // Utilizamos https://docs.oracle.com/javase/7/docs/api/java/lang/Character.html#getNumericValue(char)
        // para transformar a letra en número
        this.column=Character.getNumericValue(column)-Character.getNumericValue('A');
        if ((this.column < 0)||(this.column>25))  throw new Exception("Bad Column");
    }
    
    public Position(int row,int column) throws Exception {
        // Constructor sobrecargado da forma (0,3)
        if ((row<0)||(column<0)) throw new Exception("Bad Position");
        this.row=row;
        this.column=column;
    }
    
    public int getRow() {
        // Devolve a fila
        return row;
    }
    
    public int getColumn() {
        // Devolve a columna
        return column;
    }
    
    // Sobreposicion: Escribimos unha nova versión do método toString de Object
    // para ter una representación textual da coordenada
    @Override
    public String toString() {
        return "("+row+","+column+")";
    }
    
    /**
     * Este método non é a aplicación, so serve para probar o correcto 
     * comportamento da clase
     * 
     * @param args 
     */
    public static void main(String[] args) {
        Position p;
        int row;
        int icolumn;
        char ccolumn;
        java.util.Scanner scn;
 
        scn=new java.util.Scanner(System.in);
        try {
            System.out.println("Introduce a fila [1..n]: ");
            row=Integer.parseInt(scn.nextLine());
            System.out.println("Introduce a columna [A..Z]: ");
            ccolumn=scn.nextLine().charAt(0); // Lemos unha liña e recuperamos a primeira letra
            p=new Position(row,ccolumn);
            System.out.println("Creada Coordenada: "+p);
        } catch (Exception e) {
            System.out.println("ERROR: "+e.getMessage());
        }
        try {
            System.out.println("Introduce a fila [0..n]: ");
            row=Integer.parseInt(scn.nextLine());
            System.out.println("Introduce a columna [0..n]: ");
            icolumn=Integer.parseInt(scn.nextLine());
            p=new Position(row,icolumn);
            System.out.println("Creada Coordenada: "+p);
        } catch (Exception e) {
            System.out.println("ERROR: "+e.getMessage());
        }
    }
}
