/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package othello;

import java.util.Random;

/**
 *
 * @author xavi
 */
public class Game {
    private Board board;
    private Player[] player;
    private int colorTurn; // quenda

    /** Constructor. Crea o xogo para os xogadores indicados
     * - crea o tableiro e o pon na posición inicial
     * - establece o turno inicial
     * 
     * @param p1
     * @param p2
     */
    public Game(Player p1, Player p2) {
        board=new Board(8,8); 
        player=new Player[2];    // Creamos un Array de 2 players
        player[0]=p1;            // player[0] e p1 referencian ao mesmo Player
        player[1]=p2;            // player[1] e p2 referencian ao mesmo Player
        setRandomPlayerColor();
        init();  // Lanza exception
    }
    
    /**
     * Xogo
     */
    public void runGame() {
        int black;
        int white;
        Player blackPlayer=player[colorTurn]; // comezan negras...;
        Player whitePlayer=player[1-colorTurn];
        Position p;
        
        board.print();
        do { // Mentras non remate o xogo
            try {
                p=player[colorTurn].doMovement();  // O xogador, elixe posición
                play(p); // Facemos a xogada
                board.print();  // Visualizamos/Actualizamos o tableiro
                // Cambio de turno si o outro xogador ten xogada
                if (canPlay(player[1-colorTurn])) colorTurn=1-colorTurn; 
            } catch(Exception e) {
                System.out.println("Movemento Erróneo: "+e.getMessage());
            }
        } while(!end());
        // Comprobamos o gañador
        black=board.count(1);
        white=board.count(2);
        if (black > white)
            System.out.println("Winner "+blackPlayer+" ("+black+" to "+white+")");
        else if (white > black) 
                System.out.println("Winner "+whitePlayer+" ("+white+" to "+black+")");
             else
                System.out.println("Equality !!!"+" ("+white+" to "+black+")");
    }

    /** Realiza a xogada na posición p do tableiro
    * lanza o erro en caso de xogada non legal segundo as normas do xoto
    */
    public void play(Position p) throws Exception {
        // Comprobamos si cumple coas normas de xogo, e imos anotando
        // as fichas que temos que "voltear". Temos 8 direccións:
        // esquerda, dereita, arriba, abaixo, diagonal esquerda arriba,
        // diagonal esquerda abaixo, diagonal dereita arriba e diagonal dereita abaixo
        // Arriba, Abaixo, Esquerda, Dereita, ArribaEsquerda, AbaixoEsquerda, ArribaDereita, AbaixoDereita
        int[] reverse={0,0,0,0,0,0,0,0};
        int total;
        int color=player[colorTurn].getColor(); 
        total=reverse[0]=testUp(p,color);
        total+=(reverse[1]=testDown(p,color));
        total+=(reverse[2]=testLeft(p,color));
        total+=(reverse[3]=testRight(p,color));
        total+=(reverse[4]=testUpLeft(p,color));
        total+=(reverse[5]=testDownLeft(p,color));
        total+=(reverse[6]=testUpRight(p,color));
        total+=(reverse[7]=testDownRight(p,color));
        if (total==0) throw new Exception("Illegal Position"); // Non se revolve ninguha ficha
        
        // Si é fora do tableiro ou está ocupada lanza Exception
        board.put(p,color);
        reverse(p,color,reverse); // Damos a volta as fichas
    }

    /**
     * Indica si o xogador p ten algunha xogada posible.
     * @param p
     * @return
     * @throws Exception 
     */
    public boolean canPlay(Player p) {
        // devolve true si o xogador p pode xogar..
        try { 
            // board.get pode lanzar excepcións, eu sei que non se lanzan porque 
            // as coordenadas están entre 0 e 8
            for(int r=0;r<8;r++)
                for(int c=0;c<8;c++) {
                    // countPlay conta as fichas volteadas a partir da posición r,c
                    if ((countPlay(p,r,c)>0)&&(board.get(r,c)==0)) return true;
                }
        } catch(Exception e) {
            // Non fago nada. Nunca se vai a producir a excepción
        }
        return false;
    }

    public boolean end() {
        // true si ningun xogador ten xogada posible (o xogo finaliza)
        return (!canPlay(player[0]) && !canPlay(player[1]));
    }

    // Estou obrigado a tratar a exception ou a relanzala
    // a capturo, sei que nunca se vai a producir...
    private void init() {
        // Inicializa o taboleiro. E privada, porque so a usa o constructor
        try {
            board.put(3,3,1);
            board.put(4,4,1);
            board.put(3,4,2);
            board.put(4,3,2); 
        } catch(Exception e) {
            // Nunca se vai producir a excepción
        }
    }
    
    private void setRandomPlayerColor() {
        // Sortea as fichas dos xogadores e establece o turno inicial. 
        // É privada porque so a usa o constructor
        // Usamos a clase Random:
        // https://docs.oracle.com/javase/8/docs/api/java/util/Random.html
        Random r=new Random();
        int color;
        
        r.setSeed(System.currentTimeMillis());  // Usamos os milisegundos como semilla para o número ao azar
        color = r.nextInt(2); // Numero 0 ou 1
        player[0].setColor(color+1); // Si color é 0 1, si color é 1, 2
        player[1].setColor(1-color+1); // Si color é 0, 2. Si color é 1, 1
        
        colorTurn=color;    // Comenza o xogador de color 1 (negras)
    }

    /**
     * Devolve o número de fichas que se reviran si xoga en p
     * @param p
     * @param colorTurn
     * @return 
     */
    private int testDown(Position p, int color) {
        int r=p.getRow()+1; // Comezamos na posición seguinte a que miramos
        int c=p.getColumn();
        int piece;
        int cta=0;
                
        try {
            piece=board.get(r,c);
            while(piece!=color) {
                if (piece==0) throw new Exception("Void Cell"); 
                cta++;
                r++; // Down
                piece=board.get(r,c);
            }
        } catch(Exception e) { // Fora do tableiro ou celda vacía...
            cta=0; // Non se reviran fichas
        }
        return cta;
    }

    private int testUp(Position p, int color) {
        int r=p.getRow()-1; // Comezamos na posición anterior a que miramos
        int c=p.getColumn();
        int piece;
        int cta=0;
                
        try {
            piece=board.get(r,c);
            while(piece!=color) {
                if (piece==0) throw new Exception("Void Cell"); 
                cta++;
                r--; // Up
                piece=board.get(r,c);
            }
        } catch(Exception e) { // Fora do tableiro...
            cta=0;
        }
        return cta;
    }

    private int testLeft(Position p, int color) {
        int r=p.getRow(); 
        int c=p.getColumn()-1; // Comezamos na posición anterior a que miramos
        int piece;
        int cta=0;
        
        try {
            piece=board.get(r,c);
            while(piece!=color) {
                if (piece==0) throw new Exception("Void Cell"); 
                cta++;
                c--; // left
                piece=board.get(r,c);
            }
        } catch(Exception e) { // Fora do tableiro...
            cta=0;
        }
        return cta;
    }

    private int testRight(Position p, int color) {
        int r=p.getRow(); 
        int c=p.getColumn()+1; // Comezamos na posición anterior a que miramos
        int piece;
        int cta=0;
        
        try {
            piece=board.get(r,c);
            while(piece!=color) {
                if (piece==0) throw new Exception("Void Cell"); 
                cta++;
                c++; // right
                piece=board.get(r,c);
            }
        } catch(Exception e) { // Fora do tableiro...
            cta=0;
        }
        return cta;
    }

    private int testUpLeft(Position p, int color) {
        int r=p.getRow()-1; // Arriba esquerda da posición na que miramos
        int c=p.getColumn()-1; 
        int piece;
        int cta=0;
        
        try {
            piece=board.get(r,c);
            while(piece!=color) {
                if (piece==0) throw new Exception("Void Cell"); 
                cta++;
                r--; // up
                c--; // left
                piece=board.get(r,c);
            }
        } catch(Exception e) { // Fora do tableiro...
            cta=0;
        }
        return cta;
    }

    private int testDownLeft(Position p, int color) {
        int r=p.getRow()+1; // Abaixo a esquerda da posición na que miramos
        int c=p.getColumn()-1; 
        int piece;
        int cta=0;
        
        try {
            piece=board.get(r,c);
            while(piece!=color) {
                if (piece==0) throw new Exception("Void Cell"); 
                cta++;
                r++; // down
                c--; // left
                piece=board.get(r,c);
            }
        } catch(Exception e) { // Fora do tableiro...
            cta=0;
        }
        return cta;
    }

    private int testUpRight(Position p, int color) {
        int r=p.getRow()-1; // Arriba a dereita da posición na que miramos
        int c=p.getColumn()+1; 
        int piece;
        int cta=0;
        
        try {
            piece=board.get(r,c);
            while(piece!=color) {
                if (piece==0) throw new Exception("Void Cell"); 
                cta++;
                r--; // Up
                c++; // Right
                piece=board.get(r,c);
            }
        } catch(Exception e) { // Fora do tableiro...
            cta=0;
        }
        return cta;
    }

    private int testDownRight(Position p, int color) {
        int r=p.getRow()+1; // Abaixo a dereita da posición na que miramos
        int c=p.getColumn()+1; 
        int piece;
        int cta=0;
        
        try {
            piece=board.get(r,c);
            while(piece!=color) {
                if (piece==0) throw new Exception("Void Cell"); 
                cta++;
                r++; // down
                c++; // right
                piece=board.get(r,c);
            }
        } catch(Exception e) { // Fora do tableiro...
            cta=0;
        }
        return cta;
    }
    
    /**
     * Lle da a volta as pezas indicadas en reverse.
     * Si algunha volta non é correcta, reverse está mal calculado e non serve
     * reverse conten o número de pezas a invertir nas direccións:
     * Arriba, Abaixo, Esquerda, Dereita, ArribaEsquerda, AbaixoEsquerda, ArribaDereita, AbaixoDereita
     * @param reverse 
     */
    private void reverse(Position p, int color, int[] reverse) throws Exception {
        int row;
        int column;
        int currentcolor;
        
        // reverseUp
        //
        row=p.getRow()-1;
        column=p.getColumn();
        while(reverse[0]>0) {
            currentcolor=board.get(row,column);
            // Para revirar ten que existir ficha e ser de outra cor
            if ((currentcolor==0)||(currentcolor==color)) throw new Exception("Error reversing");
            board.set(row,column,color);
            row--; 
            reverse[0]--;
        }
        
        // reverseDown
        row=p.getRow()+1;
        while(reverse[1]>0) {
            currentcolor=board.get(row,column);
            // Para revirar ten que existir ficha e ser de outra cor
            if ((currentcolor==0)||(currentcolor==color)) throw new Exception("Error reversing");
            board.set(row, column, color);
            row++; 
            reverse[1]--;
        }
        
        // reverseLeft
        row=p.getRow();
        column=p.getColumn()-1;
        while(reverse[2]>0) {
            currentcolor=board.get(row,column);
            // Para revirar ten que existir ficha e ser de outra cor
            if ((currentcolor==0)||(currentcolor==color)) throw new Exception("Error reversing");
            board.set(row,column,color);
            column--; 
            reverse[2]--;
        }
        
        // reverseRight
        column=p.getColumn()+1;
        while(reverse[3]>0) {
            currentcolor=board.get(row,column);
            // Para revirar ten que existir ficha e ser de outra cor
            if ((currentcolor==0)||(currentcolor==color)) throw new Exception("Error reversing");
            board.set(row,column,color);
            column++; 
            reverse[3]--;
        }
        
        // reverseUpLeft
        row=p.getRow()-1;
        column=p.getColumn()-1;
        while(reverse[4]>0) {
            currentcolor=board.get(row,column);
            // Para revirar ten que existir ficha e ser de outra cor
            if ((currentcolor==0)||(currentcolor==color)) throw new Exception("Error reversing");
            board.set(row,column,color);
            column--;
            row--;
            reverse[4]--;
        }
        
        // reverseDownLeft
        row=p.getRow()+1;
        column=p.getColumn()-1;
        while(reverse[5]>0) {
            currentcolor=board.get(row,column);
            // Para revirar ten que existir ficha e ser de outra cor
            if ((currentcolor==0)||(currentcolor==color)) throw new Exception("Error reversing");
            board.set(row,column,color);
            column--;
            row++;
            reverse[5]--;
        }
        
        // reverseUpRight
        row=p.getRow()-1;
        column=p.getColumn()+1;
        while(reverse[6]>0) {
            currentcolor=board.get(row,column);
            // Para revirar ten que existir ficha e ser de outra cor
            if ((currentcolor==0)||(currentcolor==color)) throw new Exception("Error reversing");
            board.set(row,column,color);
            column++;
            row--;
            reverse[6]--;
        }
        // reverseDownRight
        row=p.getRow()+1;
        column=p.getColumn()+1;
        while(reverse[7]>0) {
            currentcolor=board.get(row,column);
            // Para revirar ten que existir ficha e ser de outra cor
            if ((currentcolor==0)||(currentcolor==color)) throw new Exception("Error reversing");
            board.set(row,column,color);
            column++;
            row++;
            reverse[7]--;
        } 
    }

    /**
     * Método auxiliar para contar o número de fichas que revolve a xogada en r,c
     * @param player
     * @param r
     * @param c
     * @return 
     */
    private int countPlay(Player player, int r, int c) throws Exception {
        int total;
        int color=player.getColor();
        Position p=new Position(r,c); // Non me interesa sobrecargar todos estes métodos...
       
        total=testUp(p,color);
        total+=testDown(p,color);
        total+=testLeft(p,color);
        total+=testRight(p,color);
        total+=testUpLeft(p,color);
        total+=testDownLeft(p,color);
        total+=testUpRight(p,color);
        total+=testDownRight(p,color);
        return total;
    }
}