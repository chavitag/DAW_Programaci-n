/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package othello;

import java.util.Random;

/**
 *
 * @author xavi
 */
public class Game {
    private Board board;
    private Player[] player;
    private int colorTurn; // quenda

    /** Constructor. Crea o xogo para os xogadores indicados
     * - crea o tableiro e o pon na posición inicial
     * - establece o turno inicial
     * 
     * @param p1
     * @param p2
     */
    public Game(Player p1, Player p2) {
        board=new Board(8,8); 
        player=new Player[2];    // Creamos un Array de 2 players
        player[0]=p1;            // player[0] e p1 referencian ao mesmo Player
        player[1]=p2;            // player[1] e p2 referencian ao mesmo Player
        setRandomPlayerColor();
        init();  // Pon as pezas na posición inicial
    }
    
    /**
     * Getter para o taboleiro
     * @return 
     */
    Board getBoard() {
        return board;
    }
    
    /**
     * Xogo
     */
    public void runGame() {
        int black;
        int white;
        Player blackPlayer=player[colorTurn]; // comezan negras...;
        Player whitePlayer=player[1-colorTurn];
        Position p;
        
        board.print();
        do { // Mentras non remate o xogo
            try {
                p=player[colorTurn].doMovement();  // O xogador, elixe posición
                play(p); // Facemos a xogada
                board.print();  // Visualizamos/Actualizamos o tableiro
                // Cambio de turno si o outro xogador ten xogada
                if (canPlay(player[1-colorTurn])) colorTurn=1-colorTurn; 
            } catch(Exception e) {
                System.out.println("Movemento Erróneo: "+e.getMessage());
            }
        } while(!end());
        // Comprobamos o gañador
        black=board.count(1);
        white=board.count(2);
        if (black > white)
            System.out.println("Winner "+blackPlayer+" ("+black+" to "+white+")");
        else if (white > black) 
                System.out.println("Winner "+whitePlayer+" ("+white+" to "+black+")");
             else
                System.out.println("Equality !!!"+" ("+white+" to "+black+")");
    }

    /** Realiza a xogada na posición p do tableiro
    * lanza o erro en caso de xogada non legal segundo as normas do xoto
     * @param pos: Posicion da xogada
     * @throws java.lang.Exception
    */
    public void play(Position pos) throws Exception {
        // Comprobamos si cumple coas normas de xogo, e imos anotando
        // as fichas que temos que "voltear". Temos 8 direccións:
        // esquerda, dereita, arriba, abaixo, diagonal esquerda arriba,
        // diagonal esquerda abaixo, diagonal dereita arriba e diagonal dereita abaixo
        // Arriba, Abaixo, Esquerda, Dereita, ArribaEsquerda, AbaixoEsquerda, ArribaDereita, AbaixoDereita
        int[] reverse={0,0,0,0,0,0,0,0};
        int total;
        int color=player[colorTurn].getColor(); 
        total=countPlay(player[colorTurn],pos,reverse);
        if (total==0) throw new Exception("Illegal Position"); // Non se revolve ninguha ficha
        
        // Si é fora do tableiro ou está ocupada lanza Exception
        board.put(pos,color);
        reverseAll(pos,color,reverse); // Damos a volta as fichas
    }

    public boolean end() {
        // true si ningun xogador ten xogada posible (o xogo finaliza)
        return (!canPlay(player[0]) && !canPlay(player[1]));
    }

    /**
     * Conta o número de fichas que revolve a xogada en r,c
     * @param player
     * @param p
     * @param rev: Array que gardará o número de fichas a voltear en cada dirección
     *  é un obxecto, polo tanto rev ten a referencia do array.
     * @return 
     * @throws java.lang.Exception 
     */
    int countPlay(Player player, Position p,int[] rev) throws Exception {
        int total;
        int color=player.getColor();
        if (rev==null) rev=new int[8];  // Si rev é null, creo o array...
       
        total=rev[0]=test(p,color,-1,0); // Up
        total+=(rev[1]=test(p,color,1,0)); // Down
        total+=(rev[2]=test(p,color,0,-1)); // Left
        total+=(rev[3]=test(p,color,0,1)); // Right
        total+=(rev[4]=test(p,color,-1,-1)); // UpLeft
        total+=(rev[5]=test(p,color,1,-1)); // DownLeft
        total+=(rev[6]=test(p,color,-1,1)); // UpRight
        total+=(rev[7]=test(p,color,1,1)); // DownRight
        
        return total;
    }
        
    // Estou obrigado a tratar a exception ou a relanzala
    // a capturo, sei que nunca se vai a producir...
    private void init() {
        // Inicializa o taboleiro. E privada, porque so a usa o constructor
        try {
            board.put(3,3,1);
            board.put(4,4,1);
            board.put(3,4,2);
            board.put(4,3,2); 
        } catch(Exception e) {
            // Nunca se vai producir a excepción
        }
    }
    
    /**
     * Indica si o xogador p ten algunha xogada posible.
     * @param player
     * @return 
     */
    private boolean canPlay(Player player) {
        Position pos;
        // devolve true si o xogador p pode xogar..
        try { 
            // board.get pode lanzar excepcións, eu sei que non se lanzan porque 
            // as coordenadas están entre 0 e 8
            for(int r=0;r<8;r++)
                for(int c=0;c<8;c++) {
                    // countPlay conta as fichas volteadas a partir da posición r,c
                    pos=new Position(r,c);
                    if ((countPlay(player,pos,null)>0)&&(board.get(r,c)==0)) return true;
                }
        } catch(Exception e) {
            // Non fago nada. Nunca se vai a producir a excepción
        }
        return false;
    }
    
    private void setRandomPlayerColor() {
        // Sortea as fichas dos xogadores e establece o turno inicial. 
        // É privada porque so a usa o constructor
        // Usamos a clase Random:
        // https://docs.oracle.com/javase/8/docs/api/java/util/Random.html
        Random r=new Random();
        int color;
        
        r.setSeed(System.currentTimeMillis());  // Usamos os milisegundos como semilla para o número ao azar
        color = r.nextInt(2); // Numero 0 ou 1
        player[0].setColor(color+1); // Si color é 0 1, si color é 1, 2
        player[1].setColor(1-color+1); // Si color é 0, 2. Si color é 1, 1
        
        colorTurn=color;    // Comenza o xogador de color 1 (negras)
    }

    /**
     * 
     * @param p: Position to test
     * @param color: Color to test
     * @param drow: Direction row (-1 up, 0 horizontal, 1 down)
     * @param dcolumn: Direction column (-1 left, 0 vertical, 1 right)
     * @return 
     */
    private int test(Position p,int color,int drow,int dcolumn) {
        int r=p.getRow()+drow; // Comezamos na posición seguinte a que miramos
        int c=p.getColumn()+dcolumn;
        int piece;
        int cta=0;
                
        try {
            piece=board.get(r,c);
            while(piece!=color) {
                if (piece==0) throw new Exception("Void Cell"); 
                cta++;
                r+=drow; 
                c+=dcolumn;
                piece=board.get(r,c);
            }
        } catch(Exception e) { // Fora do tableiro ou celda vacía...
            cta=0; // Non se reviran fichas
        }
        return cta;
    }
    
    /**
     * Lle da a volta as pezas indicadas en reverse.
     * Si algunha volta non é correcta, reverse está mal calculado e non serve
     * reverse conten o número de pezas a invertir nas direccións:
     * Arriba, Abaixo, Esquerda, Dereita, ArribaEsquerda, AbaixoEsquerda, ArribaDereita, AbaixoDereita
     * @param reverse 
     */
    private void reverse(Position p, int color, int drow, int dcolumn,int nrev) throws Exception {
        int row;
        int column;
        int currentcolor;
        
        row=p.getRow()+drow;
        column=p.getColumn()+dcolumn;
        while(nrev>0) {
            currentcolor=board.get(row,column);
            // Para revirar ten que existir ficha e ser de outra cor
            if ((currentcolor==0)||(currentcolor==color)) throw new Exception("Error reversing");
            board.set(row,column,color);
            row+=drow;
            column+=dcolumn;
            nrev--;
        }
    }
         
    private void reverseAll(Position p, int color, int[] reverse) throws Exception {
        reverse(p,color,-1,0,reverse[0]); // Up
        reverse(p,color,1,0,reverse[1]); // Down
        reverse(p,color,0,-1,reverse[2]); // Left
        reverse(p,color,0,1,reverse[3]); // Right
        reverse(p,color,-1,-1,reverse[4]); // LeftTop
        reverse(p,color,1,-1,reverse[5]); // LeftBottom
        reverse(p,color,-1,1,reverse[6]); // RightTop
        reverse(p,color,1,1,reverse[7]); // RigthBottom
    }
}