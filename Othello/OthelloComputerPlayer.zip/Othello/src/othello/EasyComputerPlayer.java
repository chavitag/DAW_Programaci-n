package othello;

/**
 *
 * @author xavi
 */
public class EasyComputerPlayer extends Player {
    private Game game;
    
    public EasyComputerPlayer(String name) {
        super(name);
    }
    
    public void setGame(Game g) {
        game=g;
    }
    
    // ESTRATEXIA: Xogar no primeiro sitio que se poda
    // Necesitamos: 
    //  a) Que o método countPlay de Game sexa accesible. Asi sei si podo xogar
    //     na posición e o número de fichas que gaño
    //  b) Poder acceder ao atributo board de game para
    //     poder planificar a estratexia, e saber si unha posición está libre
    public Position doMovement() throws Exception {
        Board board=game.getBoard();
        int total;
        Position pos=null;
        
        for(int f=0;f<8;f++) {
            for(int c=0;c<8; c++) {
                if (board.get(f,c)==0) { // Si a posición non ten ficha
                    pos=new Position(f,c);
                    total=game.countPlay(this,pos,null);
                    if (total!=0) return pos; // Aquí podo xogar
                }
            }
        }
        return null;
    }
   
}
