/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package othello;

/**
 *
 * @author xavi
 */
class Player {
    private String name; // Nome do xogador
    private int color; // Neste xogo pode ser 1 ou 2

    public Player(String name) {
        // Constructor
        this.name=name;
    }
    
    public String getName() {
        // devolve o Nome
        return name;
    }
    
    public int getColor() {
        // devolve o Color
        return color;
    }
    
    public void setColor(int c) {
        // asigna un color ao xogador
        color=c;
    }
    
    /**
     * Elixe a posición da xogada. Lanza unha excepción si a posición elexida
     * non é válida
     * @return
     * @throws Exception 
     */
    public Position doMovement() throws Exception {
        int row;
        char column;
        Position p;
        String line;
        java.util.Scanner scn=new java.util.Scanner(System.in);
             
        // this almacena a referencia ao obxecto actual, un Player 
        // automáticamente a JVM chama a toString para convertir o Player
        // na súa representación String
        /*System.out.print(this+": Introduce a fila [1..8]: ");
        row=Integer.parseInt(scn.nextLine());
        System.out.print(this+": Introduce a columna [A..Z]: ");*/
        System.out.print("Xogada de "+this+"\n [1..8][A..Z]?: ");
        line=scn.nextLine();
        row=(int)(line.charAt(0)-'0'); // Recuperamos a primeira letra, e a convertimos nun número
        column=line.charAt(1); // Recuperamos a segunda letra
        return new Position(row,column);
    }
    
    // Sobreposicion: Escribimos unha nova versión do método toString de Object
    // para ter una representación textual do Player
    @Override
    public String toString() {
        // Chamamos ao método estático de Board para ter a representación da ficha
        return name+" (color: "+Board.strPiece(color)+")";
    }
}
