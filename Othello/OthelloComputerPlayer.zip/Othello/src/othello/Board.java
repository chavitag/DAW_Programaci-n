/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package othello;

import java.io.IOException;

/**
 *
 * @author xavi
 */
class Board {
    // Para que sexa flexible, permitirá crear taboleiros de calqueira tamaño
    private int[][] cells; 
    
    public Board(int nr,int nc) {
        // Constructor. Crea un taboleiro de nr x nc
        cells=new int[nr][nc];
    }
    
    /** Pon a cela indicada pola posición á cor indicada por color.
    * si a posición é ilegal, lanza un erro
    */
    public void put(Position p,int color) throws Exception {
        verifyPosition(p);
        if (cells[p.getRow()][p.getColumn()]!=0) throw new Exception(p+": Cell is not empty ");
        cells[p.getRow()][p.getColumn()]=color;
    }
    
    // Sobrecarga de put, para permitir poñer pezas con fila,columna
    // en lugar de posición (a usa init en Game
    public void put(int row,int column, int color) throws Exception {
        verifyPosition(row,column);
        if (cells[row][column]!=0) throw new Exception("("+row+","+column+"): Cell is not empty ");
        cells[row][column]=color;
    }

    /**
     * Pon a cela a color aínda que esté ocupada
     * @param row
     * @param column
     * @param color
     * @throws Exception 
     */
    public void set(int row,int column,int color) throws Exception {
        verifyPosition(row,column);
        cells[row][column]=color;
    }
    
    /** devolve a cor da cela da posición p.
    *  si a posición é ilegal, lanza un erro....
    * @param p
    * @return 
    */
    public int get(Position p) throws Exception {
        verifyPosition(p);
        return cells[p.getRow()][p.getColumn()];
    }
    
    /**
     * Método get sobrecargado. O necesito en game para obter fácilmente
     * o valor da cela a partir de fila e columna en lugar de da posición
     * evitando ter que crear un obxecto Position. 
     * @param row
     * @param column
     * @return
     * @throws Exception 
     */
    public int get(int row,int column) throws Exception {
        verifyPosition(row,column);
        return cells[row][column];
    }

    /**
     * Representaremos con - as negras e con + as brancas
     */
    public void print() {
        // Visualiza o tableiro
        int r;
        int c;
        // Borro a consola
        clearConsole();
        System.out.print("  "); // Deixo sitio para a columna de coordenadas
        // Poñemos as letras na primeira fila...
        for(c=0;c<cells[0].length;c++) {
            System.out.print((char)(c+'A')+" ");
        }
        for (r=0;r<cells.length;r++) {
            System.out.print("\n"+(r+1)+" ");
            for(c=0;c<cells[0].length;c++) {
                System.out.print(strPiece(cells[r][c])+" ");
            }
        }
        System.out.println();
    }
       
    /**
     * Conta as celdas que teñen a ficha color.
     * O algoritmo é equivalente con while... <
     * int count=0;
     * int r=0;
     * while(r<cells.length) {
     *   c=0;
     *   while(c<cells[0].length) {
     *      if (cells[r][c]==color) count=count+1;
     *      c=c+1;
     *   }
     *   f=f+1;
     * }
     * return count;
     * @param color
     * @return 
     */
    public int count(int color) {
        // Devolve o número das fichas que ten o taboleiro da cor indicada
        int count=0;
        for(int r=0; r<cells.length; r++) {
            for (int c=0; c<cells[0].length; c++) {
                if (cells[r][c]==color) count++;
            }
        }
        return count;
    }

    public static char strPiece(int color) {
        char[] piece={' ','-','+'}; // Representación das fichas, Vacío, Negra, Branca

        return piece[color];
    }
    
    /**
     * Verifica que a posición p é correcta.
     * Position xa fai unhas comprobacións básicas...
     * @param p
     * @throws Exception 
     */
    private void verifyPosition(Position p) throws Exception {
        int r=p.getRow();
        int c=p.getColumn();
    
        // A posición é ilegal si cae fora de cells
        if (r>=cells.length) throw new Exception(p+": Row out of range ");
        if (c>=cells[0].length) throw new Exception(p+": Column out of range ");
    }
    
    /**
     * Verifica que a coordenada (row,column) é correcta.
     * Sobrecarga o método anterior, para poder utilizalo no método put sobreposto
     * @param row
     * @param column
     * @throws Exception 
     */
    private void verifyPosition(int row,int column) throws Exception {
        // A posición é ilegal si cae fora de cells
        if ((row<0)||(row>=cells.length)) throw new Exception("Row out of range ");
        if ((column<0)||(column>=cells[0].length)) throw new Exception("Column out of range ");
    }
    
    private void clearConsole()   {
        try  {
            final String os = System.getProperty("os.name");

            if (os.contains("Windows")) {
                Runtime.getRuntime().exec("cls");
            } else {
                Runtime.getRuntime().exec("clear");
            }
        } catch (IOException e) {
        }
    }
}