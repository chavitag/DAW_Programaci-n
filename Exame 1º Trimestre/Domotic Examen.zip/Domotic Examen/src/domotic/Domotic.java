package domotic;

import java.util.Scanner;

/**
 *
 * @author xavi
 */
public class Domotic {
    private static final Scanner SCN=new Scanner(System.in);
    static final int SALON=0;
    static final int HPRINCIPAL=1;
    static final int HINVITADOS=2;
    static final int COCIÑA=3;
    
    AireAcondicionado aire;
    Persiana[] persianas;
    Lampada[] lampadas;
    
    public Domotic() {
        persianas=new Persiana[3];
        lampadas=new Lampada[4];
        aire=new AireAcondicionado();
        persianas[SALON]=new Persiana("Salón");
        persianas[HPRINCIPAL]=new Persiana("Habitación Principal");
        persianas[HINVITADOS]=new Persiana("Habitación de Invitados");
        lampadas[SALON]=new Lampada("Salón",250);
        lampadas[HPRINCIPAL]=new Lampada("Habitación Principal",80);
        lampadas[HINVITADOS]=new Lampada("Habitación de Invitados",80);
        lampadas[COCIÑA]=new Lampada("Cociña",150);
    }
    
    public void opera(AireAcondicionado ac) {
        String[] menu={"Ver Estado", "Configurar", "Voltar" };
        int op=menu("Operacions con "+ac,menu);
        int humidade, temperatura;
        
        System.out.println();
        switch(op) {
            case 1:
                System.out.println(ac);
                break;
            case 2:
                try {
                    System.out.print("Temperatura (12ºC-30ºC)?:");
                    temperatura=Integer.parseInt(SCN.nextLine());
                    System.out.print("Humidade (10%-80%)?:");
                    humidade=Integer.parseInt(SCN.nextLine());
                    ac.set(humidade,temperatura);
                } catch(Exception e) {
                   System.out.println("ERROR "+e.getMessage());
                }
                break;
        }
    }
    
    public void opera(Lampada l) {
        String[] menu={"Ver Estado", "Configurar", "Voltar" };
        int op=menu("Operacions con "+l,menu);
        int lumens;
        
        System.out.println();
        switch(op) {
            case 1:
                System.out.println(l);
                break;
            case 2:
                try {
                    System.out.print("Luminosidade?:");
                    lumens=Integer.parseInt(SCN.nextLine());
                    l.set(lumens);
                } catch(Exception e) {
                   System.out.println("ERROR "+e.getMessage());
                }
                break;
        }
     }
    
    public void opera(Persiana p) {
        String[] menu={"Ver Estado", "Configurar", "Voltar" };
        int op=menu("Operacions con "+p,menu);
        int posicion;
        
        System.out.println();
        switch(op) {
            case 1:
                System.out.println(p);
                break;
            case 2:
                try {
                    System.out.print("Posición (0-100)?:");
                    posicion=Integer.parseInt(SCN.nextLine());
                    p.set(posicion);
                } catch(Exception e) {
                   System.out.println("ERROR "+e.getMessage());
                }
                break;
        }
    }
    
    public void menuLampada() {
        String[] menu={"Salón","Habitación Principal","Habitación Invitados","Cociña","Voltar"};
        int op;
        op=menu("Elixe Lámpada",menu);
        if (op<5) opera(lampadas[op-1]);
    }
    
    public void menuPersiana() {
        String[] menu={"Salón","Habitación Principal","Habitación Invitados","Voltar"};
        int op;
        op=menu("Elixe Persiana",menu);
        if (op<4) opera(persianas[op-1]);
    }
        
    public void menuAireAcondicionado() {
        opera(aire);
    }
    
    public static void main(String[] args) {
        int op;
        String[] mainmenu={"Aire Acondicionado","Lampadas","Persianas","Saír"};

        Domotic app=new Domotic();
        do {
            op=menu("Menú Principal",mainmenu);
            try {
                switch(op) {
                    case 1: 
                        app.menuAireAcondicionado();
                        break;
                    case 2:
                        app.menuLampada();
                        break;
                    case 3: 
                        app.menuPersiana();
                        break;
                }
            } catch(Exception e) {
                System.out.println("ERROR: "+e.getMessage());
            }
            
        } while(op!=4);
    }
    
    // Utilidades
    
    public static String line(int len) {
        String line="";
        for(int idx=0;idx<len;idx++) line+="-";
        return line;
    } 

    public static int menu(String title,String[] ops) {
        int op;
        int idx;
        do {
            System.out.println("\n\n"+title+"\n"+line(title.length()));
            for(idx=0;idx<ops.length;idx++) {
                System.out.println((idx+1)+".- "+ops[idx]);
            }
            System.out.print("Elixe opcion: ");
            try {
                op=Integer.parseInt(SCN.nextLine());
            } catch(NumberFormatException e) {
                op=0;
            }
        } while ((op<1) || (op > idx));
        return op;
    }
}
