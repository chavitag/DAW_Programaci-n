package domotic;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xavi
 */
public class LampadaCor extends Lampada {
    private final static String[] strcores={"BRANCO","AZUL","MARELO","VERMELLO","VIOLETA"};
    private int cor;
    
    public LampadaCor(String name,int maxlumens) {
        super(name,maxlumens);
        cor=0;
    }
    
    public void setCor(String cor) throws Exception {
        int idx;
        
        for(idx=0;idx<strcores.length;idx++) {
            if (cor.equals(strcores[idx])) break;
        }
        if (idx==strcores.length) throw new Exception("Unknown Color");
        this.cor=idx;
        System.out.println("Posta cor de "+getNome()+" a "+cor);
    }
    
    @Override
    public String toString() {
        int lumens=getLumens();
        String nome=getNome();
        String str="Lampada "+nome+" ";
        if (lumens==0)  str="(Apagada)";
        else            str+="(Brilo "+lumens+" lumens na cor "+strcores[cor]+")";
        return str;
    }
    
    public static void main(String[] args) {
        try {
            LampadaCor l=new LampadaCor("TestLamp",150);
            l.on();
            l.setCor("AZUL");
            l.set(30);
            System.out.println("Estado da lámpada: "+l);
            l.off();
        } catch(Exception e) {
            System.out.println("ERROR: "+e.getMessage());
        }
    }
}
