package domotic;

/**
 *
 * @author xavi
 */
public class AireAcondicionado {
    private int humidade=0;
    private int temperatura=0;
    
    public void set(int humidade,int temperatura) throws Exception {
        setHumidade(humidade);
        setTemperatura(temperatura);
    }
    
    public void setHumidade(int humidade) throws Exception {
        if ((humidade < 10) || (humidade > 80)) throw new Exception("Bad Humedity percent");
        this.humidade=humidade;
        System.out.println("Establecida a humidade a "+humidade+"%");
    }
    
    public void setTemperatura(int temperatura) throws Exception {
        if ((temperatura<12) || (temperatura > 30)) throw new Exception("Bad Temperature");
        this.temperatura=temperatura;
        System.out.println("Establecida a temperatura a "+temperatura+"ºC");
    }
    
    public void off() {
        humidade=0;
        temperatura=0;
        System.out.println("Aire Acondicionado apagado");
    }
    
    @Override
    public String toString() {
        String str=" Aire Acondicionado";
        if (humidade==0) str+=" Apagado";
        else {
            str+=": Humidade "+humidade+"%, Temperatura "+temperatura+"ºC";
        }
        return str;
    }
    
}
