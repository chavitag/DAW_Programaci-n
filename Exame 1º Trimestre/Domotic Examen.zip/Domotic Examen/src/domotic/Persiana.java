/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domotic;

/**
 *
 * @author xavi
 */
public class Persiana {
    private final String name; // final. unha vez posto o nome non imos cambialo
    private int position;
    
    Persiana(String name) {
        this.name=name;
        this.position=0;
    }
    
    public void set(int position) throws Exception {
        if ((this.position<0)||(this.position>100)) throw new Exception("Bad Position");
        this.position=position;
        System.out.println(this);
    }
    
    public void open() {
        try {
            set(100);
        } catch(Exception e) {
            System.out.println("CRITICAL ERROR: "+e.getMessage());
            System.exit(1);
        }
    }
    
    public void close() {
        try {
            set(0);
        } catch(Exception e) {
            System.out.println("CRITICAL ERROR: "+e.getMessage());
            System.exit(1);
        }
    }
    
    @Override
    public String toString() {
        String ret="Persiana "+name;
        switch (position) {
            case 100:
                ret+=" subida";
                break;
            case 0:
                ret+=" baixada";
                break;
            default:
                ret+=" na posicion "+position;
                break;
        }
        return ret;
    }
}
