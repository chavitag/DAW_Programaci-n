/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domotic;

/**
 *
 * @author xavi
 */
public class Lampada {
    private final String nome;
    private final int maxlumens;
    private int lumens; 
    
    public Lampada(String nome,int maxlumens) {
        this.nome=nome;
        this.maxlumens=maxlumens;
        this.lumens=0;
    }
    
    public void set(int lumens) throws Exception {
        if ((lumens < 0) || (lumens > maxlumens)) throw new Exception("Bad luminosity");
        this.lumens=lumens;
        System.out.println(this);
    }
    
    public void on() {
        this.lumens=1;
        System.out.println("Lámpada: "+nome+" encendida (Brilo mínimo)");
    }
    
    public void off() {
        this.lumens=0;
        System.out.println(this);
    }
    
    public String getNome() {
        return nome;
    }
    
    public int getLumens() {
        return lumens;
    }
    
    @Override
    public String toString() {
        String str="Lampada: "+nome+" ";
        if (lumens==0)  str+="(Apagada)";
        else            str+="(Brilo "+lumens+" lumens)";
        return str;
    }
    
    public static void main(String[] args) {
        try {
            Lampada l=new Lampada("TestLamp",150);
            l.on();
            l.set(30);
            System.out.println("Estado -> "+l);
            l.off();
        } catch(Exception e) {
            System.out.println("ERROR: "+e.getMessage());
        }
    }
}
