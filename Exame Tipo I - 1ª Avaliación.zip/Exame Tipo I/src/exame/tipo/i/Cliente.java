/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exame.tipo.i;

import java.util.Scanner;

/**
 *
 * @author xavi
 */
public class Cliente extends Persoa {
    // Facemos os atributos privados para que non se podan manipular dende fora
    private String numeroConta;
    private float saldo;
    
    /** CONSTRUCTOR
     */
    public Cliente(String dni, String nome, String apelidos, int idade, String numeroConta, float saldo) 
            throws Exception {
      super(dni, nome, apelidos, idade);    // Chamamos ao construtor da clase base.
      if (!verificaConta(numeroConta)) throw new Exception("Número de conta erróneo");
      this.saldo = saldo;
      this.numeroConta = numeroConta;         
    }

    public void print(){
        System.out.println("\nDatos cliente\n------------------------");
        System.out.println("DNI: " + this.dni);
        System.out.println("Nome y apelidos: " + this.nome + " " + this.apelidos);
        System.out.println("Numero de conta: " + this.numeroConta);
        System.out.println("Saldo disponible: " + this.saldo);    
    }
    
    // Sopreposición de toString. Servirá para amosar en qué consiste
    // o polimorfismo. NON forma parte do examen
    @Override 
    public String toString() {
        return dni+" - "+nome+" "+apelidos+"\n - Conta corrente: "+numeroConta+" Saldo: "+saldo;
        
    }
    
    public void aumentarSaldo(float numero){
        this.saldo += numero;
    }
    
    public void fixarSaldo(float numero){
        this.saldo = numero;
    }
    
    public void disminuirSaldo(float numero) throws Exception {
        if (this.saldo<numero) throw new Exception("Saldo insuficiente");
        this.saldo -= numero;
    }
     
    private boolean verificaConta(String num) throws Exception {
        String cuenta = num;
        String bloque1; 
        String bloque2;
        boolean result=false;

        // Isto pode lanzar unha NumberFormatException que é unha unchecked exception
        // polo que se nos permite ignorala. Eu especifico o throws porque ten relevancia
        // si non é un número, a conta é incorrecta... pero si non o indico tamén está ben
        if (num.length()==20) {
            bloque1= "00" + cuenta.substring(0, 8);
            bloque2=cuenta.substring(10, 20);
            result=(Integer.parseInt(cuenta.substring(8, 9)) == comprobaDixito(bloque1) &&
                    Integer.parseInt(cuenta.substring(9, 10)) == comprobaDixito(bloque2));
        }
        return result;
    }
    
    private int comprobaDixito(String cuenta){
        int[] tablaFactores = {1, 2, 4, 8, 5, 10, 9, 7, 3, 6};
        int suma = 0;
        int cv;
        
        for(int i = 0; i < 10; i++){
            // Isto pode lanzar unha unckecked exception, non o indico porque non 
            // me parece relevante, e así vedes que pasa si non se indica.... nada
            // funciona igual.
            int digito = Integer.parseInt(cuenta.substring(i, i+1));
            suma += digito * tablaFactores[i];
        }
        // Esta é a solución correcta segundo o enunciado
        cv=(11 - (suma % 11)); 
       
        // Esto non está no enunciado, pero é necesario para que a verificación
        // Funcione... o algoritmo está mal no enunciado. Falta unha "corrección"
        // No caso en que cv sexa maior que 9 (10 ou 11) debemos reducilo a un díxito
        // cando é 10 a 1 e si é 11 a 0....
        if (cv > 9) cv=(cv/10)-(cv%10);  // Si é > 9 resto os seus díxitos...
        
        /*
        Alternativamente:
            if (cv==10) cv=1;
            else if (cv==11) cv=0;
        */
        return cv;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Facede varias probas, con clientes con DNI e números de conta correctos
        // e falsos...
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce o numero de DNI");
        String dni = sc.nextLine();
        System.out.println("Introduce o nome");
        String nome = sc.nextLine();
        System.out.println("Introduce los apelidos");
        String apelidos = sc.nextLine();
        System.out.println("Introduce a idade");
        int idade = Byte.parseByte(sc.nextLine());
        System.out.println("Introduce o numero de conta");
        String numeroConta = sc.nextLine();
        try {
            Cliente cliente1 = new Cliente(dni, nome, apelidos, idade, numeroConta, 150);
            cliente1.print();
        } catch(Exception e) {
            System.out.println("ERRO: "+e.getMessage());
        }
        
        // Contestación a última pregunta.... SI, xa que os Cliente son persoas...
        Persoa[] p=new Persoa[20];
        try {
            // http://www.genware.es/index.php?ver=cuentasbancarias#
            // http://www.generador-de-dni.com/generador-de-dni
            p[0]=new Cliente("97728248Y", "Test 1", "De Proba 1", 1, "55620021158021111836", 150);
            // POLIMORFISMO. Aínda que p[0] ten unha "Persoa", se executa o método toString do Cliente
            // xa que é unha Persoa de tipo Cliente...
            System.out.println("\nCreado cliente "+p[0]);
            // Temos que indicar que a Persoa é un Cliente porque Cliente non ten método print
            ((Cliente)p[0]).print(); 
            p[1]=new Cliente("13872725E", "Test 2", "De Proba 2", 2, "43881208060526510384", 150);
            // POLIMORFISMO. Aínda que p[0] ten unha "Persoa", se executa o método toString do Cliente
            // xa que é unha Persoa de tipo Cliente...
            System.out.println("\n\nCreado cliente "+p[1]);
            // Temos que indicar que a Persoa é un Cliente porque Cliente non ten método print
            ((Cliente)p[1]).print();
        } catch(Exception e) {
            System.out.println("ERRO: "+e.getMessage());
        }    
    } 
}
