/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exame.tipo.i;

/**
 *
 * @author xavi
 */
public class Persoa {
    // Os atributos son "protected" para que podamos utilizalos con facilidade nas
    // clases heredadas e non sexan accesibles dende fora
    protected String dni;
    protected String nome;
    protected String apelidos;
    protected int idade;

    // Constructor. Si o DNI é erróneo lanza unha Exception notificando o fallo
    //
    public Persoa (String dni, String nome, String apelidos, int idade) throws Exception  {
        if(!verificaDni(dni)) throw new Exception("Número de DNI Erróneo");
        this.dni = dni;          
        this.nome = nome;
        this.apelidos = apelidos;
        this.idade = idade;
    }

    public void setDni(String dni){
        this.dni = dni;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public void setApelidos(String apelidos){
        this.apelidos = apelidos;
    }
        
    public void setIdade(byte idade){
        this.idade = idade;
    }
   
    public String getDni(){
        return this.dni;
    }
    
    public String getNome(){
        return this.nome;
    }
    
    public String getApelidos(){
        return this.apelidos;
    }
    
    public int getIdade(){
        return this.idade;
    }
    
    // Sopreposición de toString. Servirá para amosar en qué consiste
    // o polimorfismo. NON forma parte do examen
    @Override 
    public String toString() {
        return dni+" - "+nome+" "+apelidos+" ("+idade+")";
        
    }

    // Verifica que o DNI sexa correcto, devolve true ou false segundo o caso
    //
    private boolean verificaDni(String num) throws Exception {
        char[] letras = {'T','R','W','A','G','M','Y','F','P','D','X','B','N','J','Z','S','Q','V','H','L','C','K','E'};
        char letra = num.charAt(num.length() - 1);
        String dni = num.substring(0, num.length() - 1);
        // parseInt pode producir unha NumberFormatException, pero ao ser unha
        // unchecked Exception non sería obrigatorio poñer o throws. O poñemos para 
        // indicar que ese erro sí importa...
        int numero = Integer.parseInt(dni); 
        int resto = numero % 23;
        return (letras[resto] == letra);
    }
}
