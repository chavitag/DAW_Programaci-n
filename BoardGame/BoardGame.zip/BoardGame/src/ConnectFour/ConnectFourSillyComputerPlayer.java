/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ConnectFour;

import boardgames.Board;
import boardgames.ColumnMove;
import boardgames.Move;
import boardgames.Player;

/**
 *
 * @author xavi
 */
public class ConnectFourSillyComputerPlayer extends Player {

    public ConnectFourSillyComputerPlayer(String name) {
        super(name);
    }
     /**
     * Realiza o movemento do xogo. 
     * Xoga no primeiro sitio que pode
     * @return - Movemento a realizar
     * @throws java.lang.Exception - Lanza unha excepción si a Position é ilegal
     */
    @Override
    public Move doMovement() throws Exception {
        ConnectFourGame thisGame=(ConnectFourGame)game;
        Board board=game.getBoard();
        int column;
        
        board.show();   // Visualiza o estado do taboleiro
        for(column=0;(column<8)&&(board.get(0,column)!=null);column++);
        System.out.println(this+" ("+thisGame.pieces[this.getPieceId()]+"): "+((char)(column+'A')));
        return new ColumnMove(column);
    } 
}
