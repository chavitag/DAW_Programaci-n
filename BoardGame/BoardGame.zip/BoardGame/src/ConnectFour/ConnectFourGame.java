/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ConnectFour;

import boardgames.Board;
import boardgames.BoardGame;
import boardgames.ColumnMove;
import boardgames.Move;
import boardgames.Piece;
import boardgames.Player;
import java.util.Random;

/**
 *
 * @author xavi
 */
public class ConnectFourGame extends BoardGame {
    Piece[] pieces;             // Pezas do xogo
    Player winner=null;         // Garda o gañador
    Random rnd=new Random();    // Xerador de azar do xogo
    
    public ConnectFourGame(Player playerOne, Player playerTwo) {
        super(playerOne, playerTwo);
        rnd.setSeed(System.currentTimeMillis());  // Usamos os milisegundos como semilla para o número ao azar
    }
    
     @Override
    protected int initGame() {
        int color;

        color=rnd.nextInt(2);     // Número ao azar : 0 ou 1
        board=new Board(8,8);   // Novo Tableiro de 8x8
        pieces=new Piece[2];    // Podemos repetir a referencia en varias celas. Una peza pode estar en varias celas
        pieces[0]=new Piece("Brancas","+",1);
        pieces[1]=new Piece("Negras","-",2);
        player[0].setPieceId(color);	// O xogador 0 pode levar “Brancas” (pieces[0] ) ou “Negras” (pieces[1])
        player[1].setPieceId(1-color);   // O xogador 1 leva o contrario que o xogador 0
        return color;   // Comezan sempre brancas 
    }
    
    /**
     * Realiza o movimento move conforme as regras do xogo (Othello).
     * Si a xogada é errónea lanza unha excepción
     * @param move          - xogada a realizar de tipo ColumnMove (polimorfismo)
     * @throws Exception    - Se lanza si a xogada non é legal
     */
    @Override
    public void doPlay(Move move) throws Exception {
        int column=((ColumnMove)move).column;
        int row=0;
        while((row<8)&&(board.get(row,column)==null)) row++;    // A ficha "cae"
        // player[turn] - Xogador actual
        // player[turn].getPieceId(); - ID da ficha do xogador actual (índice)
        // pieces[....] - Ficha do xogador actual
        board.put(row-1,column,pieces[player[turn].getPieceId()]);
    }
    
    /**
     * Indica si o xogo finaliza. O xogo finaliza cando ningún pode xogar
     * @return - True si o xogo finaliza, False en caso contrario
     */
    @Override
    public boolean endGame() {
        // O xogo remata si se enche o taboleiro ou si
        // o último xogador en xogar fixo 4 en raia
        
        return (isWinner(player[1-turn]))||(isBoardFull());
    }
    
    /**
     * Determiña quen gañou
     * @return - O Player que gañou a partida. null en caso de empate
     */
    public Player getWinner() {
        return winner;
    }

    private boolean isWinner(Player player) {
        boolean result=true;
        //int[] connected=new int[4];
        Piece piece=pieces[player.getPieceId()];
        Piece in_piece;
        
        try {
            for(int row=0;row<8;row++) {
                for(int column=0;column<8;column++) {
                    in_piece=board.get(row,column);
                    if ((in_piece!=null)&&(piece.equals(in_piece))) {
                        if (isConnectFour(piece,row,column)>3) {
                            winner=player;
                            return true;
                        }
                    }
                }
            }
        } catch(Exception e) {
            System.out.println("ERROR: "+e.getMessage());
            System.exit(1);
        }
        return false;
    }

    private boolean isBoardFull() {
        try {
            for(int column=0;column<8;column++) {
                if (board.get(0,column)==null) return false;
            }
        } catch(Exception e) { // Nunca debe pasar, xa que column nunca é erróneo
            System.out.println("ERROR:"+e.getMessage());
            System.exit(1);
        }
        return true;
    }

    /**
     * Indica o número máximo de pezas iguais que se consigue poñendo piece 
     * en (row,col)
     * @param piece
     * @param row
     * @param col
     * @return - Número máximo de pezas iguais conseguidas
     * @throws Exception 
     */
    int isConnectFour(Piece piece,int row, int col) throws Exception {
        int n;
        n=scan(row,col,piece,-1,0);  // Vertical
        n=Math.max(n,scan(row,col,piece,0,-1));  // Horizontal
        n=Math.max(n,scan(row,col,piece,-1,-1)); // Diagonal esquerda
        n=Math.max(n,scan(row,col,piece,-1,1));  // Diagonal dereita
        return n;
    }
    
    private int scan(int row, int col, Piece piece,int drow,int dcol) {
        int cr=row+drow;
        int cc=col+dcol;
        int count=1;
        try {
            while(board.get(cr,cc)!=null && piece.equals(board.get(cr,cc))) {
                cr+=drow;
                cc+=dcol;
                count++;
            }
        } catch (Exception e) {  // Fora do tableiro. simplemente deixamos esa busca
        }
        
        try {
            drow=-drow;
            dcol=-dcol;
            cr=row+drow;
            cc=col+dcol;
            while(board.get(cr,cc)!=null && piece.equals(board.get(cr,cc))) {
                cr+=drow;
                cc+=dcol;
                count++;
            }
        } catch(Exception e) {  // Fora do tableiro. simplemente deixamos a busca
        }
        return count;
    }
}
