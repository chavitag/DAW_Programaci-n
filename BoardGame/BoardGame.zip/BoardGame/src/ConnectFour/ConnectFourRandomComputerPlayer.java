/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ConnectFour;

import boardgames.Board;
import boardgames.ColumnMove;
import boardgames.Move;
import boardgames.Piece;
import boardgames.Player;
import boardgames.Position;

/**
 * En primeiro lugar intenta facer catro en raia, se non, impide o catro en raia do contrario
 * por últmino xoga ao azar
 * @author xavi
 */
public class ConnectFourRandomComputerPlayer extends Player {

    public ConnectFourRandomComputerPlayer(String name) {
        super(name);
    }
    
    /**
     * Realiza o movemento do xogo. En orde mira o seguinte:
     * - Intenta facer 4 en raia
     * - Impide que o contrario faga 4 en raia
     * - Elixe unha columna ao azar
     * @return - Movemento a realizar
     * @throws java.lang.Exception - Lanza unha excepción si a Position é ilegal
     */
    @Override
    public Move doMovement() throws Exception {
        ConnectFourGame thisGame=(ConnectFourGame)game;
        Position[] scan=new Position[8];  // Indica as posicións posibles
        Piece piece=thisGame.pieces[this.getPieceId()];     // Peza do xogador actual
        Piece opiece=thisGame.pieces[1-this.getPieceId()];  // Peza do contrario
        Board board;
        int row,column,max,colmax,tot,idx;
        
        board=thisGame.getBoard();
        board.show();   // Visualiza o estado do taboleiro
        
        // Gardo en scan as posicións de xogada posibles
        idx=0;
        for(column=0;column<8;column++) {
            if (board.get(0,column)==null) {
                row=0; 
                while((row<8) && (board.get(row,column)==null)) row++; // Fila a que cae a ficha
                scan[idx]=new Position(row-1,column);
                idx++;
            }
        }
        // Comprobo si fago 4 en raia en algunha
        for(column=0;column<idx;column++) {
             if (thisGame.isConnectFour(piece,scan[column].getRow(),scan[column].getColumn())>3) {
                 break; // Posición gañadora
             }
        }
        if (column==idx) { // Non se atopou 4 en raia....
            // Comprobo o contrario fai 4 en raia en algunha
            max=0; colmax=-1;
            for(column=0;column<idx;column++) {
                // Comprobamos o número de fichas alineadas, e nos quedamos coa posición do máximo
                tot=thisGame.isConnectFour(opiece,scan[column].getRow(),scan[column].getColumn());
                if (tot>max) {
                    max=tot;
                    colmax=scan[column].getColumn();
                }
                if (max>3)  break;    // O máximo é 4, posición perdedora, debemos impedilo
            }
            // Non existe 4 en raia. Impide ter 3 en raia, e si non é necesario elixe columna ao azar
            if (column==idx)    {
                if (max>2)  column=colmax;      // Impedimos 3 en raia
                else        column=scan[thisGame.rnd.nextInt(idx)].getColumn();
            } else  column=scan[column].getColumn();
        } else column=scan[column].getColumn();

        System.out.println(this+" ("+thisGame.pieces[this.getPieceId()]+"): "+((char)(column+'A')));
        return new ColumnMove(column);
    } 
}
