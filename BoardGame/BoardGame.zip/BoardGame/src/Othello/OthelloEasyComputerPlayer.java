/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package Othello;

import boardgames.Board;
import boardgames.Move;
import boardgames.Player;
import boardgames.Position;
import boardgames.PositionMove;

/**
 * Implementa un Player que xoga no primeiro sitio que atopa
 * @author Javier Taboada
 */
public class OthelloEasyComputerPlayer extends Player {
    
    /**
     * Constructor
     * @param name 
     */
    public OthelloEasyComputerPlayer(String name) { 
        super(name);  
    }
    
    /**
     * Movemento: Primeiro sitio posible
     * @return - Movemento a realizar
     * @throws java.lang.Exception
     */
    @Override
    public Move doMovement() throws Exception  {
        Board board=game.getBoard(); // Recuperamos o taboleiro do xogo
        int total;
        Position pos;

        board.show();
        for(int f=0;f<8;f++) { // Recorremos as filas
            for(int c=0;c<8; c++) { // Para cada fila, recorremos as columnas
                if (board.get(f,c)==null) { // Si a posición non ten ficha, e posible que se poda xogar...
                    pos=new Position(f,c);
                    total=((OthelloGame)game).countPlay(this,pos,null);
                    if (total!=0) {
                        System.out.println(this+": "+pos);  // Indico a xogada en pantalla
                        return new PositionMove(pos);
                    } 
                }
            }
        }
        return null;  // Aquí nunca debería chegar a execución. O  xogo non manda xogar si non existe xogada
    }
}
