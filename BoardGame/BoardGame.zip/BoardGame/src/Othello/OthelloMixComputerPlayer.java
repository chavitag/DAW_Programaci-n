/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package Othello;

import boardgames.Board;
import boardgames.Move;
import boardgames.Position;
import boardgames.PositionMove;

/**
 *
 * @author xavi
 */
public class OthelloMixComputerPlayer extends OthelloMaxPointsComputerPlayer {

    /**
     * Constructor
     * @param name 
     */
    public OthelloMixComputerPlayer(String name) { 
        super(name);
    }

    /**
     * Estratexia: Os mais cercanos as esquinas, ou o de máxima captura
     * @return
     * @throws Exception 
     */
    @Override
    public Move doMovement() throws Exception {
        Board board=game.getBoard();
        Position[] corner=getFreeCell();  // Obtemos as 4 celdas libres máis próximas ás esquinas
        Position pos=null;
        
        for(int i=0;(i<4)&&(pos==null);i++) {
            if ((corner[i]!=null)&&(((OthelloGame)game).countPlay(this, corner[i], null)!=0)) {
                pos=corner[i];
            }
        }
        if (pos==null) return super.doMovement(); // Chamamos ao método de MaxPointsComputerPlayer
        board.show();
        System.out.println(this+" (MIX): "+pos);   // Con MIX distinguimos que estratexia elexiu a Posición
        return new PositionMove(pos);    
    }
    
    /** 
     * Método auxiliar 
     * Devolve as catro primeiras celdas libres máis próximas as esquinas
     * @return unha táboa coas 4 celdas máis cercanas as esquinas e bordes
     */
    private Position[] getFreeCell()  {
        int inc=0;
        int rowi=0;
        int rowf=7;
        int coli=rowi;
        int colf=rowf;
        Board board=game.getBoard();
        Position[] pos=new Position[4];
        
        try {
	    while(rowi<rowf) {
	        while(coli<colf) {
	            if ((pos[0]==null)&&(board.get(rowi,coli)==null)) pos[0]=new Position(rowi,coli);
	            if ((pos[1]==null)&&(board.get(rowi,colf)==null)) pos[1]=new Position(rowi,colf);
	            if ((pos[2]==null)&&(board.get(rowf,colf)==null)) pos[2]=new Position(rowf,colf);
	            if ((pos[3]==null)&&(board.get(rowf,coli)==null)) pos[3]=new Position(rowf,coli);
	            coli++;
	            colf--;
	            if ((pos[0]!=null)&&(pos[1]!=null)&&(pos[2]!=null)&&(pos[3]!=null)) return pos;
	        }
	        // Percorre as diagonais hacia o centro
	        rowi++;
	        rowf--;
	        coli=rowi;
	        colf=rowf;
	    }
        } catch (Exception e) {  // board.get lanza unha excepción si a posición é erronea. Nunca debería pasar...
            e.printStackTrace();
            System.exit(1);
        }
        return pos;
    }
}