/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package Othello;

import boardgames.Board;
import boardgames.BoardGame;
import boardgames.Move;
import boardgames.Piece;
import boardgames.Player;
import boardgames.Position;
import boardgames.PositionMove;
import java.util.Random;

/**
 * Xogo do Othello. Extende BoardGame
 * 
 * @author Javier Taboada
 */
public class OthelloGame extends BoardGame {
    Piece[] pieces;	// No Othello xogamos con 2 fichas. Unha negra e outra branca...

    public OthelloGame(Player playerOne, Player playerTwo) {
	super(playerOne,playerTwo);
    }

    /**
     * Debe sortear as pezas, crear o taboleiro (Board) e poñer as pezas na posición inicial. 
     * NON se pode realizar, xa que é específica de cada xogo.
     * @return - Número do xogador que comeza o xogo
     */
    @Override
    protected int initGame() {
        int color;
        Random r=new Random();

        r.setSeed(System.currentTimeMillis());  // Usamos os milisegundos como semilla para o número ao azar
        color=r.nextInt(2);     // Número ao azar : 0 ou 1
        board=new Board(8,8);   // Novo Tableiro de 8x8
        pieces=new Piece[2];    // Podemos repetir a referencia en varias celas. Una peza pode estar en varias celas
        pieces[0]=new Piece("Brancas","+",1);
        pieces[1]=new Piece("Negras","-",2);
        player[0].setPieceId(color);	// O xogador 0 pode levar “Brancas” (pieces[0] ) ou “Negras” (pieces[1])
        player[1].setPieceId(1-color);   // O xogador 1 leva o contrario que o xogador 0
        // Posición inicial do tableeiro
        try {
            board.put(3,3,pieces[0]);  // Branca
            board.put(4,4,pieces[0]);  // Branca
            board.put(3,4,pieces[1]);  // Negra
            board.put(4,3,pieces[1]);  // Negra 
        } catch(Exception e) { // Teño a obriga de tratar a posible Exception, pero nunca se debe producir   
            e.printStackTrace();
            System.exit(1); // Rematamos a aplicación
        }
        return (1-color);   // Si color é 0, as negras as leva player[1] e viceversa
    }

    /**
     * Realiza o movimento move conforme as regras do xogo (Othello).
     * Si a xogada é errónea lanza unha excepción
     * @param move          - xogada a realizar de tipo PositionMove (polimorfismo)
     * @throws Exception    - Se lanza si a xogada non é legal
     */
    @Override
    public void doPlay(Move move) throws Exception {
        // reverse gardará as fichas que gaña o movemento nas distintas direccións:
        // Arriba, Abaixo, Esquerda, Dereita, ArribaEsquerda, AbaixoEsquerda, ArribaDereita, AbaixoDereita
        int[] reverse={0,0,0,0,0,0,0,0};
        int total;				// Total de fichas que se gañan co movemento
        PositionMove pm=(PositionMove) move;    // O Move é un PositionMove, facemos casting
        int pieceId=player[turn].getPieceId();  // Recuperamos a peza que ten o xogador

        // Contamos cantas fichas gaña o movemento en en qué direccións
        total=countPlay(player[turn],pm.position,reverse);
        if (total==0) throw new Exception("Illegal Position"); // Non se gaña ninguha ficha. Movemento ERRÓNEO
        // Board lanza unha Exception si a posición está fora do tableiro ou está ocupada
        board.put(pm.position,pieces[pieceId]);
        reverseAll(pm.position,pieces[pieceId],reverse); // Damos a volta as fichas
   }

    /**
     * Cambia o turno
     */
    @Override
    public void changeTurn() {
        if (canPlay(player[1-turn])) turn=1-turn; 
    }

    /**
     * Indica si o xogo finaliza. O xogo finaliza cando ningún pode xogar
     * @return - True si o xogo finaliza, False en caso contrario
     */
    @Override
    public boolean endGame() {
        return (!canPlay(player[0]) && !canPlay(player[1]));
    }

   // **  Determina quen foi o gañador: 0 empate, 1 xogador 1, 2 xogador 2
    @Override
    public Player getWinner() {
	Piece piece0=pieces[player[0].getPieceId()];
	Piece piece1=pieces[player[1].getPieceId()];
        int total0=board.count(piece0);
        int total1=board.count(piece1);

        if (total0 == total1) return null;
        if (total0 > total1) return player[0];
        return player[1];
    }
    
    /**
     * Conta o número de fichas que 'captura' a xogada en p.
     * enche a táboa rev co número de fichas capturadas nas distintas direccións
     * ten que ser friendly porque a necesitan os Player para as súas estratexias
     * @param player    - Xogador actual
     * @param pos       - Posición da xogada
     * @param rev       - Array onde deixamos o número de fichas capturadas nas distintas direccións
     * @return          - O número total de fichas capturadas
     * @throws Exception  - Lanza unha excepción si a posición e errónea
     */
    int countPlay(Player player, Position pos,int[] rev) throws Exception {
        int total;
        int pieceId=player.getPieceId();
        if (rev==null) rev=new int[8];  // Si rev é null, creo o array...
       
        total=rev[0]=test(pos,pieces[pieceId],-1,0);        // Up
        total+=(rev[1]=test(pos,pieces[pieceId],1,0));      // Down
        total+=(rev[2]=test(pos,pieces[pieceId],0,-1));     // Left
        total+=(rev[3]=test(pos,pieces[pieceId],0,1));      // Right
        total+=(rev[4]=test(pos,pieces[pieceId],-1,-1));    // UpLeft
        total+=(rev[5]=test(pos,pieces[pieceId],1,-1));     // DownLeft
        total+=(rev[6]=test(pos,pieces[pieceId],-1,1));     // UpRight
        total+=(rev[7]=test(pos,pieces[pieceId],1,1));      // DownRight  
        return total;
    }

    /**
     * Indica si o xogador p ten algunha xogada posible. 
     * E accesible dende o paquete (friendly) porque os xogadores o necesitan para 
     * calcular o movimento
     * @param player - Xogador do que queremos saber si ten xogada posible
     * @return       - True si player ten algunha xogada, False noutro caso
     */
    boolean canPlay(Player player) {
        Position pos;
        
        try { // board.get pode lanzar excepcións..
            for(int r=0;r<8;r++) {
                for(int c=0;c<8;c++) {
                    pos=new Position(r,c);
                    // countPlay conta as fichas volteadas a partir da posición r,c
                    if ((countPlay(player,pos,null)>0)&&(board.get(r,c)==null)) return true;
                }
            }
        } catch(Exception e) { // Nunca se debe a producir a excepción
            e.printStackTrace();
            System.exit(1);
        }
        return false;
    }

    // Pon ao valor Piece as celas indicadas pola táboa reverse
    /**
     * "Captura" as pezas indicadas na táboa reverse a partir da posición pos
     * @param pos       - Posición de comezo
     * @param piece     - Ficha que realiza a "captura"
     * @param reverse   - Número de fichas a capturar nas distintas direccións
     * @throws Exception - Si se produce un erro na captura se lanza a excepción
     */
    private void reverseAll(Position pos, Piece piece, int[] reverse) throws Exception {
        reverse(pos,piece,-1,0,reverse[0]); 	// Up
        reverse(pos,piece,1,0,reverse[1]); 	// Down
        reverse(pos,piece,0,-1,reverse[2]);	// Left
        reverse(pos,piece,0,1,reverse[3]); 	// Right
        reverse(pos,piece,-1,-1,reverse[4]); 	// LeftTop
        reverse(pos,piece,1,-1,reverse[5]); 	// LeftBottom
        reverse(pos,piece,-1,1,reverse[6]); 	// RightTop
        reverse(pos,piece,1,1,reverse[7]); 	// RigthBottom
    }

    /**
     * Método auxiliar para reverseAll. "Captura" nrev fichas na dirección
     * (drow,dcolumn) a partir da Position p
     * @param pos       - Posiciónde inicio de "captura"
     * @param piece     - Ficha que realiza a "captura"
     * @param drow      - Dirección de avance nas filas
     * @param dcolumn   - Dirección de avance nas columnas
     * @param nrev      - Número de fichas a capturar
     * @throws Exception - Si se produce un erro na captura se lanza unha excepción
     */
    private void reverse(Position pos, Piece piece, int drow, int dcolumn,int nrev) throws Exception {
        int row;
        int column;
        Piece currentPiece;
        
        row=pos.getRow()+drow;
        column=pos.getColumn()+dcolumn;
        while(nrev>0) {
            currentPiece=board.get(row,column);
            // Si non temos ficha ou é igual que a actual, e un erro
            if ((currentPiece==null)||(piece.equals(currentPiece))) throw new Exception("Error reversing");
            board.set(row,column,piece);
            row+=drow;
            column+=dcolumn;
            nrev--;
        }
    }
 
    /**
     * Comproba que se pode poñer piece na Position pos mirando na dirección (drow,dcolumn).
     * @param pos       - Posición de partida
     * @param piece     - Ficha que queremos poñer
     * @param drow      - Incremento das filas
     * @param dcolumn   - Incremento das columnas
     * @return          - Número de fichas que captura
     */
    private int test(Position pos,Piece piece,int drow,int dcolumn) {
        int r=pos.getRow()+drow; 		// Comezamos na posición seguinte a que miramos
        int c=pos.getColumn()+dcolumn;
        Piece boardPiece;
        int cta=0;
                
        try {
            boardPiece=board.get(r,c);		// Recuperamos a Piece do taboleiro
            while(!piece.equals(boardPiece)) {   // Mentras non sexa igual que a Piece que estamos poñendo....
                if (boardPiece==null) throw new Exception("Void Cell"); 
                cta++;				// Contamos
                r+=drow; 			// Avanzamos na dirección indicada
                c+=dcolumn;
                boardPiece=board.get(r,c);	// Recuperamos a Piece do taboleiro
            }
        } catch(Exception e) { // Fora do tableiro ou celda vacía...
            cta=0; // Non se reviran fichas
        }
        return cta;
    }
}
