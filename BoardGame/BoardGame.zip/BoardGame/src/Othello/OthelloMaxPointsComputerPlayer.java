/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package Othello;

import boardgames.Board;
import boardgames.Move;
import boardgames.Player;
import boardgames.Position;
import boardgames.PositionMove;

/**
 * Esta clase implementa un xogador "automático" para poder xogar contra o 
 * ordenador. A estratexia a seguir por este xogador e realizar o movemento na
 * posición na que captura máis fichas do contrario
 * @author xavi
 */
public class OthelloMaxPointsComputerPlayer extends Player {
    /**
     * Constructor
     * @param name: Nome do xogador 
     */
    public OthelloMaxPointsComputerPlayer(String name) {
        super(name);
    }
        
    /**
     * Calculo do movemento: Posición de máxima captura
     * @return
     * @throws Exception 
     */
    @Override
    public Move doMovement() throws Exception {
        Board board=game.getBoard();  // Recuperamos o taboleiro do xogo
        Position pos;
        Position maxpos=null;
        int total, maxtotal=0;

        board.show();
        for(int f=0;f<8;f++) { // Recorremos as filas
            for(int c=0;c<8; c++) { // Para cada fila, recorremos as columnas
                if (board.get(f,c)==null) { // Si a posición non ten ficha, e posible que se poda xogar...
                    pos=new Position(f,c);
	            total=((OthelloGame)game).countPlay(this,pos,null);
	            if (total > maxtotal) { // O total de fichas conseguidas nesta posición é maior que a gardada
                        maxpos=pos;
	                maxtotal=total;
	            }
                }
            }
        }
        System.out.println(this+": "+maxpos);  // Indico a xogada en pantalla
        return new PositionMove(maxpos);
    }
}
