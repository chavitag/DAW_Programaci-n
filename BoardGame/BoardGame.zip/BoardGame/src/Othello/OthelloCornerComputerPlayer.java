/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package Othello;

import boardgames.Board;
import boardgames.Move;
import boardgames.Player;
import boardgames.Position;
import boardgames.PositionMove;

/**
 * Player "automático" que xoga nas posicións máis cercanas as esquinas
 * @author xavi
 */
public class OthelloCornerComputerPlayer extends Player {
    
    public OthelloCornerComputerPlayer(String name) { 
        super(name);  
    }
    
    @Override
    public Move doMovement() throws Exception {
        Board board=game.getBoard(); // Recuperamos o taboleiro do xogo
        Position pos=null;
        int row=0, column=0;
        int incr=0;  	// Dirección do movemento nas filas
        int incc=1;   // Dirección do movemento nas columnas
        int maxrow=7;  // fila límite
        int maxcol=7;   // Columna límite
        int minrow=1;  // Fila de comezo
        int mincol=0;   // Columna de comezo

        board.show();
        for(int i=0;i<64;i++) {  // Recorremos as 64 celas si é necesario
            if (board.get(row,column)==null) { // Si a posición non ten ficha, e posible que se poda xogar...
                pos=new Position(row,column);
                if (((OthelloGame)game).countPlay(this,pos,null)>0) break;  // Se pode xogar, rompemos o bucle 
            }
            column=column+incc;
            row=row+incr;
            if ((column > maxcol)&&(incc!=0)) {  // Chegamos a maxcol, baixamos de fila ..
                column=maxcol;
                maxcol--;
                row++;
                incc=0;
                incr=1;
            }
            if ((row > maxrow)&&(incr!=0)) {  // Chegamos a maxrow, retrocedemos de columna ..
                row=maxrow;
                maxrow--;
                column--;
                incc=-1;
                incr=0;
            }
            if ((column < mincol)&&(incc!=0)) { // Chegamos a mincol, subimos de fila ..
                column=mincol;
                mincol++;
                row--;
                incc=0;
                incr=-1;
            }
            if ((row < minrow)&&(incr!=0)) { // Chegamos a minrow, avanzamos de columna ..
                row=minrow;
                minrow++;
                column++;
                incc=1;
                incr=0;
            }
        }
        System.out.println(this+": "+pos);
        return new PositionMove(pos);
    }
}
