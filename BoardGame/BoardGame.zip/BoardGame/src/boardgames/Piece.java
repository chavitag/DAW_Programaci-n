package boardgames;

import java.util.Objects;

/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Esta clase representa unha ficha de xogo de tableiro. Si algun xogo ten 
 * necesidades "especiais" pode crear unha clase derivada a partir de esta
 * 
 * @author Javier Taboada
 */
public class Piece {
    protected String name;  // Nome da Peza. 
    protected String image; // Representación da Peza en pantalla. 
    protected int value;      // Valor da Peza
	
    /**
     * Constructor
     * @param name  - Nome da pieza
     * @param image - Representación da Peza en pantalla
     * @param value - Valor da peza
     */
    public Piece(String name,String image,int value) {
	this.name=name;
        this.image=image;
	this.value=value;
    }

    /**
     * Constructor. Non indico o nome para poder persoalizar nas clases herdadas
     * So se permite o uso deste constructor SOBRECARGADO dende clases herdadas 
     */
    protected Piece() {    }
    
    /**
     * Getter do valor da peza
     * @return Devolve o valor da peza
     */
    public int getValue() { 
        return value;  
    }

    /**
     * Getter para o nome da peza
     * @return Devolve o nome da peza
     */
    public String getName() { 
        return name;  
    }
    
    /**
     * Getter para a image da peza
     * @return Devolve a representación da Peza en pantalla
     */
    public String getImage() {
        return image;
    }
    
    /**
     * Setter para poñer o valor da peza
     * @param value - Novo valor para a peza
     */
    public void setValue(int value) {
        this.value=value;
    }
     
    /**
     * Sobreposición de toString para visualizar a peza con facilidade
     * @return 
     */
    @Override
    public String toString() { 
        return image; 
    }

    /**
     * Sobreposición de equals.
     * Supoñemos que dúas pezas son iguais si teñen o mesmo nome e valor
     * @param opiece
     * @return 
     */
    @Override
    public boolean equals(Object opiece) {
        if (opiece==null) return false;
        if (this==opiece) return true; 	
        if (! (opiece instanceof Piece)) return false;
        Piece piece=(Piece) opiece;
        return (name.equals(piece.getName()) && (value==piece.getValue()));
    }

    /**
     * Sobreposición do hashCode.
     * Object ten un método que xenera un hascode que identifica o obxecto
     * sobrepoñer este método acelera as comparacións e as buscas.
     * NOTA: O xenerou Netbeans....
     * @return - hashcode do obxecto
     */
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.name);
        hash = 89 * hash + this.value;
        return hash;
    }
}
