/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boardgames;

/**
 * Esta clase representa os Xogos de Tableiro (Board).
 * Moitos métodos non se poden programar, esta clase está para crear clases
 * que parten de aquí para facer implementacións particulares (herdanza)
 * 
 * @author Javier Taboada
 */
public class BoardGame {
    protected Board board;      // Taboleiro - protected para que as clases que heredan podan acceder
    protected Player[] player;  // Xogadores - protected para que as clases que heredan podan acceder
    protected int turn; 	// Quenda - protected para que as clases que heredan podan acceder

    /**
     * Constructor. Crea o xogo para os xogadores indicados.
     * 
     * @param playerOne - Primeiro xogador
     * @param playerTwo - Segundo xogador
     */
    public BoardGame(Player playerOne, Player playerTwo) {
        player=new Player[2];   // Creamos un Array de 2 players
        player[0]=playerOne;    // player[0] e p1 referencian ao mesmo Player
        player[1]=playerTwo;    // player[1] e p2 referencian ao mesmo Player
    }
    
    /**
     * Getter para o taboleiro do xogo. 
     * 
     * @return - Taboleiro do xogo
     */
    public Board getBoard() { 
       return board;  
    }
  
    /**
     * Leva a cabo o xogo. 
     * Este é o método que controla a execución de todos xogos de taboleiro
     */
    public void runGame() {
        Move move=null;
        Player winner;
        
        player[0].setGame(this);    // player[0] participa en este Game
        player[1].setGame(this);    // player[1] participa en este Game
        turn=initGame();            // Crea e inicializa o taboleiro (Board) e sortea as pezas

        // Facer
        do {  
            try {
                move=player[turn].doMovement();  	// O xogador que lle toca, elixe xogada
                doPlay(move); 				// Facemos a xogada
	  	changeTurn();				// Cambio de turno
            } catch(Exception e) {  			
                System.out.println("Movemento "+move+" erróneo: "+e.getMessage()); 	// Xogada errónea
            }
        } while(!endGame());    // Mentras non remate o xogo
        board.show();           // Amosamos o estado final do tableiro
        winner=getWinner();     // Comprobamos o gañador
        if (winner==null)   System.out.println("Tie !!! (Empate)");
        else                System.out.println("And the Winner Is...."+winner+"!!!!");
    }

    /** 
     * Cambia o turno
     */
    public void changeTurn() {
	turn=1-turn;
    }
    
    /*---------------->  A partir de aquí non podo implementar os métodos, porque
      esta clase é demasiado xeral. Se verá un modo mellor de facelo cando vexamos
      as clases abstractas
    */
    
    /**
     * Debe sortear as pezas, crear o taboleiro (Board) e poñer as pezas na posición inicial. 
     * NON se pode realizar, xa que é específica de cada xogo. So se permite o seu
     * uso as clases que herdan de esta
     * @return - Número do xogador que comeza o xogo
     */
    protected int initGame() {
	throw new UnsupportedOperationException("I don’t know how create and initialize the board");
    }
    
    /**
     * Realiza o movemento si e correcto en caso contrario lanza unha excepción.
     * NON se pode realizar, porque é específico de cada xogo
     * @param move - Movemento a realizar
     * @throws Exception - Si a xogada é errónea
     */
    public void doPlay(Move move) throws Exception {
        throw new UnsupportedOperationException("I don’t know the rule’s game");
    }

    /** 
     * Realiza o movemento, si e correcto. En caso contrario lanza unha excepción
     * @return - true si o xogo finaliza, false en caso contrario
     */
    public boolean endGame() {
	throw new UnsupportedOperationException("I don’t know the rule’s game");
   }

    /**
     * Determiña quen gañou
     * @return - O Player que gañou a partida. null en caso de empate
     */
    public Player getWinner() {
	throw new UnsupportedOperationException("I don’t know the rule’s game");
    }
}
