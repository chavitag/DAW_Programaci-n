/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package boardgames;

/**
 * Representa un movimento que consiste en indicar únicamente  unha columna.
 * 
 * @author Javier Taboada
 */
public class ColumnMove extends Move {
    public int column;  // Columna onde queremos xogar a partir de 0...
    
    /**
     * CONSTRUCTOR (Sobrecargado): Crea o obxecto a partir da letra de columna A...
     * 
     * @param column - Letra indicando a columna
     * @throws Exception - Se lanza si non se pode crear unha Position nesa columna
     */
    public ColumnMove(char column) throws Exception {
        // https://docs.oracle.com/javase/7/docs/api/java/lang/Character.html#getNumericValue(char)
        // Transformamos a letra en número
        this.column=Character.getNumericValue(column)-Character.getNumericValue('A');
        if ((this.column < 0)||(this.column>25))  throw new Exception("Bad Column");
    }
    
    /**
     * CONSTRUCTOR (Sobrecargado): Crea o obxecto a partir do número de columna 0..
     * 
     * @param column - Número indicando a columna (numerada dende 0)
     * @throws Exception - Se lanza si non se pode crear unha Position nesa columna
     */
    public ColumnMove(int column) throws Exception {
        if (column<0) throw new Exception("Bad Column");
        this.column=column;
    }
    
    /**
     * Devolve a representación como String deste Move
     * @return - String coa letra representando a columna entre corchetes. 
     */
    @Override
    public String toString() {
        return "["+(((char)column)+'A')+"]";
    } 
}
