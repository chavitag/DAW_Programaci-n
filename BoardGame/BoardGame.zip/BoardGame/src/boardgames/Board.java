package boardgames;

/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.io.IOException;

/**
 * Esta clase representa un taboleiro de xogo formado por fichas 
 * (obxectos da clase Piece)
 * 
 * @author Javier Taboada
 */
public class Board {
    // Para que sexa flexible, permitirá crear taboleiros de calqueira tamaño. Unha vez creado non se pode cambiar
    private final Piece[][] cells; 
    
    /**
     * Constructor.
     * Crea un obxecto Board a partir do número de filas (nr) e de columnas (nc)
     * @param nr - Número de filas
     * @param nc - Número de columnas
     */
    public Board(int nr,int nc) {
        cells=new Piece[nr][nc];
    }

    /**
     * Pon a Piece piece na cela indicada pola Position pos
     * @param pos   - Posición na que desexamos poñer a Piece
     * @param piece - Piece que queremos poñer no Board
     * @throws Exception - Lanza a excepción si non é posible poñer piece en pos
     */
    public void put(Position pos,Piece piece) throws Exception {
        int row=pos.getRow();
        int column=pos.getColumn();
        verifyPosition(row,column);    // Lanza unha excepción si pos está fora do Board
        if (cells[row][column]!=null) throw new Exception(pos+": Cell is not empty ");
        cells[row][column]=piece;
    }
    
    /**
     * Método put sobreposto que permite poñer unha peza a partir das coordendas en
     * lugar de facelo cunha Position.
     * 
     * @param row       - Fila
     * @param column    - Columna
     * @param piece     - Piece que queremos poñer no Board en Fila,Columna
     * @throws Exception - Se lanza si non é posible poñer a Piece en Fila,Columna
     */
    public void put(int row,int column, Piece piece) throws Exception {
        verifyPosition(row,column);
        if (cells[row][column]!=null) throw new Exception("("+row+","+column+"): Cell is not empty ");
        cells[row][column]=piece;
    }

    /**
     * Almacena piece no Board en (row,column) aínda que a cela esté ocupada
     * @param row       - Fila
     * @param column    - Columna
     * @param piece     - Peza a poñer
     * @throws Exception - Se lanza unha excepción si (row,column) está fora do Board
     */
    public void set(int row,int column,Piece piece) throws Exception {
        verifyPosition(row,column);
        cells[row][column]=piece;
    }
    
    /**
     * Devolve a Piece que se atopa na posicion pos do Board
     * @param pos       - Position
     * @return          - A peza que se atopa na Position de Board. null si está baleira
     * @throws Exception - Lanza unha excepción si a Position está fora do Board
     */
    public Piece get(Position pos) throws Exception {
        int row=pos.getRow();
        int column=pos.getColumn();
        verifyPosition(row,column);
        return cells[row][column];
    }
    
    /**
     * Devolve a Piece que se atopa na posicion (row,column) do Board.
     * Este método está sobrecargado para permitir acceder por coordenadas en 
     * lugar de usar un obxecto Position
     * @param row       - Fila
     * @param column    - Columna
     * @return          - A peza que se atopa en (row,column) ou null si está baleira
     * @throws Exception - Lanza unha excepción si (row,column) non está no Board
     */
    public Piece get(int row,int column) throws Exception {
        verifyPosition(row,column);
        return cells[row][column];
    }

    /**
     * Amosa o Board na pantalla.
     */
    public void show() {
        int r;
        int c;
        
        clearConsole();         // Borro a consola
        System.out.print("  "); // Deixo sitio para a columna de coordenadas
        for(c=0;c<cells[0].length;c++) {    // Poñemos as letras na primeira fila...
            System.out.print((char)(c+'A')+" ");
        }
        for (r=0;r<cells.length;r++) {  // Pintamos as filas co seu número diante
            if (r>8) System.out.print("\n"+((char)('A'+r-9))+" ");
            else     System.out.print("\n"+(r+1)+" ");
            for(c=0;c<cells[0].length;c++) {
                if (cells[r][c]!=null) System.out.print(cells[r][c]+" ");  // se usa toString de Piece
                else                   System.out.print("  ");
            }
        }
        System.out.println();
    }
       
    /**
     * Devolve o numero de piece que ten o Board
     * @param piece - Peza a buscar no Board
     * @return      - Número de piece que ten o Board
     */
    public int count(Piece piece) {
        // Devolve o número das fichas que ten o taboleiro da cor indicada
        int count=0;
        // Esta forma de for é especial para recorrer coleccións de datos como os Array
        // cell vai collendo cada fila do Board (que é a súa vez un array...)
        for (Piece[] cell : cells) {    
            for (int c = 0; c<cells[0].length; c++) {
                if ((cell[c]!=null)&&(cell[c].equals(piece))) {
                    count++;
                }
            }
        }
        return count;
    }
    
    /**
     * Verifica que a coordenada (row,column) é correcta.
     * @param row         - fila
     * @param column      - columna
     * @throws Exception  - Lanza unha exception si (row,column) está fora do Board
     */
    private void verifyPosition(int row,int column) throws Exception {
        // A posición é ilegal si cae fora de cells
        if ((row<0)||(row>=cells.length)) throw new Exception("Row out of range ");
        if ((column<0)||(column>=cells[0].length)) throw new Exception("Column out of range ");
    }
    
    /**
     * Utilidade para borrar a pantalla da consola
     */
    private void clearConsole()   {
        try  {
            final String os = System.getProperty("os.name");

            if (os.contains("Windows")) {
                Runtime.getRuntime().exec("cls");
            } else {
                Runtime.getRuntime().exec("clear");
            }
        } catch (IOException e) {
        }
    } 
}
