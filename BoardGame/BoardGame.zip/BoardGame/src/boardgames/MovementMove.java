/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package boardgames;

/**
 * Esta clase representa xogadas que consisten en movemento de pezas de unha 
 * posición a outra, como se fai no xadrez ou damas
 * 
 * @author Javier Taboada
 */
public class MovementMove extends Move {
    Position fromPosition;  // Posición de inicio
    Position toPosition;    // Posición final

    /**
     * Crea un MovementMove dende from a to
     * @param from  - Posiciónde inicio
     * @param to    - Posición final
     */
    public MovementMove(Position from, Position to) {
        fromPosition=from;
        toPosition=to;
    }
    
   /**
     * Devolve a representación como String deste Move
     * @return - Un texto From posicion inicial to posición final
     */
    @Override
    public String toString() {
        return "From "+fromPosition+" to "+toPosition;
    } 
}
