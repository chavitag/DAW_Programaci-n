/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package boardgames;

/**
 *
 * @author xavi
 */
public class SolitaireBoardGame extends BoardGame {
    
    public SolitaireBoardGame(Player player) {
        super(player, null);
    }
    
    /**
     * Leva a cabo o xogo. Este é o método que controla a execución dos xogos de taboleiro
     */
    @Override
    public void runGame() {
        Move move=null;
        Player winner;
        
        player[0].setGame(this);    // player[0] participa en este Game
        initGame();                 // Crea e inicializa o taboleiro (Board) 

        // Facer
        do {  
            try {
                move=player[turn].doMovement();  	// O xogador que lle toca, elixe xogada
                doPlay(move); 				// Facemos a xogada
            } catch(Exception e) {  			
                System.out.println("Movemento "+move+" erróneo: "+e.getMessage()); 	// Xogada errónea
            }
        } while(!endGame());    // Mentras non remate o xogo
        board.show();           // Amosamos o estado final do tableiro
        winner=getWinner();     // null, se perdeu, != null, se gañou
        if (winner==null)   System.out.println("You Lost!!!");
        else                System.out.println("You Win!!!");
    }
    
}
