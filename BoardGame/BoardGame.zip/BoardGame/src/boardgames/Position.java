/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package boardgames;

/**
 * Esta clase representa unha posición (fila e columna) nun taboleiro
 * Dispon de un constructor sobrecargado, permitindo crear coordenadas de dous modos:
 *  Position p=new Position(5,'C');
 *  Position p=new Position(6,2);
 * 
 * @author Javier Taboada
 */
public class Position {
    private int row;        // Fila     (0..n)
    private int column;     // Columna  (0..m)
    
    /**
     * Constructor.
     * Crea un obxecto Position a partir da fila (int de 1..) e a columna (char de A..)
     * @param row           - Fila (coordenada numérica a partir de '123456789A...' )
     * @param column        - Columna (coordenada alfabética (char) a partir de 'ABCDEF...'
     * @throws Exception    - Lanza unha excepción si a coordenada non é legal
     */
    public Position(char row,char column) throws Exception {
        // Utilizamos https://docs.oracle.com/javase/7/docs/api/java/lang/Character.html#getNumericValue(char)
        // para transformar a letra en número sen importar si son maiúsculas ou minúsculas
        if ((row>'0')&&(row<='9')) this.row=(int)(row-'0')-1;
        else  this.row=10+(Character.getNumericValue(row)-Character.getNumericValue('A'))-1; // Admite minúsculas
        if (this.row<0) throw new Exception("Bad Row");
        this.column=Character.getNumericValue(column)-Character.getNumericValue('A');
        if ((this.column < 0)||(this.column>25))  throw new Exception("Bad Column");
    }
    
    /**
     * Constructor.
     * Crea un obxecto Position a partir da fila (int) e a columna (int)
     * @param row           - Fila (coordenada numérica a partir de 0)
     * @param column        - Columna (coordenada numérica a partir de 0)
     * @throws Exception    - Lanza unha excepción si a coordenada non é legal
     */
    public Position(int row,int column) throws Exception {
        if ((row<0)||(column<0)) throw new Exception("Bad Position");
        this.row=row;
        this.column=column;
    }

    /**
     * Getter para a fila
     * @return - Devolve a fila da Position
     */
    public int getRow() {
        return row;
    }
    
    /**
     * Getter para a columna
     * @return - Devolve a columna da Position
     */
    public int getColumn() {
        // Devolve a columna
        return column;
    }
    
    /**
     * Devolve a representación como String dun Position
     * @return 
     */
    @Override
    public String toString() {
        return "("+row+","+column+")";
    }    
}
