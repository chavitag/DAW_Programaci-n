/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package boardgames;

/**
 *
 * @author xavi
 */
public class HumanMovePlayer extends Player {

    public HumanMovePlayer(String name) {
        super(name);
    }
    
     /**
     * Realiza o movemento do xogo indicando un movemento dunha posición a outra
     * Un xogador humano pide a fila e columna de xogo. Este xogador pide
     * a fila e columna como cadeas da forma 1A, 3B ... etc
     * @return - Movemento a realizar
     * @throws java.lang.Exception - Lanza unha excepción si a Position é ilegal
     */
    @Override
    public Move doMovement() throws Exception {
        java.util.Scanner scn=new java.util.Scanner(System.in);
        Board board=game.getBoard();
        char orow,drow;
        char ocolumn,dcolumn;
        String line;

        board.show();   // Visualiza o estado do taboleiro
        System.out.print("Movemento de "+this+"\n Movemento? [XX]-[XX]?: ");
        line=scn.nextLine();
        orow=line.charAt(0); // Recuperamos a primeira letra, e a convertimos nun número
        ocolumn=line.charAt(1); // Recuperamos a segunda letra
        drow=line.charAt(3); // Recuperamos a primeira letra, e a convertimos nun número
        dcolumn=line.charAt(4); // Recuperamos a segunda letra
        return new MovementMove(new Position(orow,ocolumn),new Position(drow,dcolumn));
    }
    
}
