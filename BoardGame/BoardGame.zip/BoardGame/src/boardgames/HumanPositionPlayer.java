/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package boardgames;

/**
 *
 * @author xavi
 */
public class HumanPositionPlayer extends Player {

    public HumanPositionPlayer(String name) {
        super(name);
    }
    
    /**
     * Realiza o movemento do xogo indicando unha posición.
     * Un xogador humano pide a fila e columna de xogo. Este xogador pide
     * a fila e columna como cadeas da forma 1A, 3B ... etc
     * @return - Movemento a realizar
     * @throws java.lang.Exception - Lanza unha excepción si a Position é ilegal
     */
    @Override
    public Move doMovement() throws Exception {
        java.util.Scanner scn=new java.util.Scanner(System.in);
        Board board=game.getBoard();
        char row;
        char column;
        Position pos;
        String line;

        board.show();   // Visualiza o estado do taboleiro
        System.out.print("Xogada de "+this+"\n [FC]?: ");
        line=scn.nextLine();
        row=line.charAt(0); // Recuperamos a primeira letra, e a convertimos nun número
        column=line.charAt(1); // Recuperamos a segunda letra
        pos=new Position(row,column);
        return new PositionMove(pos);
    }
}
