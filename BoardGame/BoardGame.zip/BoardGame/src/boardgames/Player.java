package boardgames;

/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Esta clase representa un xogador xenérico. 
 * E necesario heredar de él para crear Players realmente funcionais
 * 
 * @author Javier Taboada
 */
public class Player {
    private final String name;    // Nome do xogador. TODOS os xogadores teñen un nome
    private int pieceId;    // ID da ficha ou do conxunto de fichas asociado ao xogador.
    protected BoardGame game; // O Player necesita coñecer a situación do xogo para planificar as xogadas

    /**
     * CONSTRUCTOR: Todos os Player se crean indicando o seu nome
     * @param name 
     */
    public Player(String name) { 
        this.name=name;  
    }
        
    /**
     * Setter para a ficha. TODOS os Player teñen un tipo de fichas do xogo 
     * @param id - Id da peza que lle corresponde ao Player no xogo
     */
    public void setPieceId(int id) {
        pieceId=id;  
    }

    /**
     * Setter para o game. TODOS os Player teñen acceso ao Game no que participan
     * @param g - Game no que participa o Player
     */
    public void setGame(BoardGame g) { 
        game=g;  
    }
    
    /**
     * Getter para o nome. TODOS os Player son capaces de indicar o seu nome
     * @return - Nome do Player
     */
    public String getName() {   
        return name;   
    }
    
    /**
     * Getter para o ID da peza que lle corresponde a este Player
     * @return 
     */
    public int getPieceId() {
        return pieceId;  
    }
    
    /**
     * Sobreposición do método toString para representar como String dun player.
     * @return - O nome do player
     */
    @Override
    public String toString() {
    	return name;
    } 
    
    /* -----------> Estes métodos non se poden implementar por ser a clase
       demasiado xenérica. Se verá un modo mellor de tratar estes casos cando
       vexamos as clases abstractas (abstract class)
    */
    
    /**
     * Realiza o movemento do xogo. Non se pode facer porque non se corresponde
     * cun xogador dun tipo concreto. Cada xogo debe crear o seu tipo de Players
     * @return - Movemento a realizar
     * @throws java.lang.Exception - E posible que lance unha exception si o movemento é ilegal
     */
    public Move doMovement() throws Exception {
        throw new UnsupportedOperationException("I don’t know how to play"); 
    }
}
