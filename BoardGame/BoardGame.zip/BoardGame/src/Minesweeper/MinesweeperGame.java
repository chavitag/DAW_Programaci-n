/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package Minesweeper;

import boardgames.Board;
import boardgames.HumanPositionPlayer;
import boardgames.Move;
import boardgames.Piece;
import boardgames.Player;
import boardgames.Position;
import boardgames.PositionMove;
import boardgames.SolitaireBoardGame;
import java.util.Random;

/**
 * Xogo do buscaminas.
 * @author xavi
 */
public class MinesweeperGame extends SolitaireBoardGame {
    Random rnd=new Random();    // Xerador de azar do xogo
    private int nbombs;
    private int nrows;
    private int ncols;
    private int discovered;
    private int end; // 1 Win, 2 Lost

    /**
     * CONSTRUCTOR: Se indica o xogador, o número de filas e columnas e o número de bombas desexado
     * @param player - Xogador
     * @param nrows  - Número de filas
     * @param ncols  - Número de columnas
     * @param nbombs - Numero de bombas
     * @throws Exception - Lanza unha excepción si as bombas son excesivas. Máximo un 80%
     */
    public MinesweeperGame(HumanPositionPlayer player,int nrows,int ncols,int nbombs) throws Exception {
        super(player);
        int maxbombs=(int)Math.ceil(nrows*ncols*80/100); // Maximo un 80% de bombas
        if (nbombs > maxbombs) throw new Exception("Too much bombs");
        this.nrows=nrows;   // Numero de filas
        this.ncols=ncols;   // Numero de columnas
        this.nbombs=nbombs; // Numero de bombas
        this.end=0; // Cando valga 1, se gañou a partida. Si vale 2 se perdeu
        this.discovered=0;  // Nº de pezas descubertas
        rnd.setSeed(System.currentTimeMillis());  // Usamos os milisegundos como semilla para o número ao azar
    }
    
    /**
     * Inicialización do xogo: Creamos o tableiro e colocamos as bombas
     * @return 
     */
    @Override
    protected int initGame() {
        try {
            board=new Board(nrows,ncols);
            fillBoard();
        } catch(Exception e) {
            System.out.println("Init board error!!! "+e.getMessage());
            e.printStackTrace();
            System.exit(1); // Saimos do programa
        }
        return 0;
    }
    
    /**
     * Realiza o movimento move conforme as regras do xogo.
     * Si a xogada é errónea lanza unha excepción
     * @param move          - xogada a realizar de tipo ColumnMove (polimorfismo)
     * @throws Exception    - Se lanza si a xogada non é legal
     */
    @Override
    public void doPlay(Move move) throws Exception {
        System.out.println("Xogada  en "+move);
        PositionMove m=(PositionMove) move;
        MinesweeperPiece p=(MinesweeperPiece)board.get(m.position.getRow(),m.position.getColumn());
        if (p.isBomb()) {
            end=2;
            discoverAll();
        }
        else {
           if (p.isHidden()) discover(m.position);
        }
    }
    
    /**
     * Indica si o xogo finaliza. O xogo finaliza cando ningún pode xogar
     * @return - True si o xogo finaliza, False en caso contrario
     */
    @Override
    public boolean endGame() {
        // Si xa temos todas as pezas descubertas, gañamos
        if (discovered==nrows*ncols-nbombs) end=1;
        return end!=0;
    }
    
    /**
     * Devolve o gañador. Si end é 2 se perdeu, e devolvemos null
     * En outro caso devolvemos o xogador...
     * @return - null si se perde, o Player actual si se gaña
     */
    @Override
    public Player getWinner() {
        if (end==2) return null;
        return player[0];
    }
    //------>  Funcións Auxiliares
    
    /**
     * Inicializa o tableiro colocando as bombas e o resto de Pezas
     * Calcula o valor das pezas segundo a proximiade ás bombas
     * @throws Exception 
     */
    private void fillBoard() throws Exception {
        int totcells=ncols*nrows;       // Total de celas
        Position[] filledArray=new Position[totcells]; // Táboa auxiliar
        Position[] trackArray=new Position[totcells];  // Posicións válidas
        int fcellsIdx,pbomb,track,tbombs;
        Piece bomb;
        int rowaux;
        int colaux;
        
        // Inicializamos as posicións válidas e a táboa auxiliar
        fcellsIdx=0;
        for(int row=0;row<nrows;row++) {
            for(int col=0;col<ncols;col++) {
                filledArray[fcellsIdx]=new Position(row,col);
                trackArray[fcellsIdx]=filledArray[fcellsIdx];
                fcellsIdx++;
            }
        }
        
        // Creamos a bomba
        bomb=new MinesweeperPiece("BOMB");
        // Poñemos as bombas
        tbombs=0;
        while(tbombs<nbombs) {
            // Sorteo entre as posicións válidas e colocación da bomba. 
            // En fcellsIdx teño o número de posicións válidas en trackArray
            pbomb=rnd.nextInt(fcellsIdx); 
            board.put(trackArray[pbomb],bomb);
            
            rowaux=trackArray[pbomb].getRow();
            colaux=trackArray[pbomb].getColumn();
            pbomb=rowaux*ncols+colaux;  // Posición en filledArray
            filledArray[pbomb]=null;
            // ###############################################################
            // Este código elimina as posicíóns que están pegadas a unha bomba 
            // para impedir que se xeneren dúas bombas xuntas
            //#################################################################
            /*
            // Si non corresponde a unha primeira columna
            if (colaux>0) filledArray[pbomb-1]=null;
             // SI non corresponde a unha última columna
            if (colaux<ncols-1) filledArray[pbomb+1]=null; 
            track=pbomb-ncols; // fila anterior
            if (track>0) {
                filledArray[track]=null;
                if (colaux>0) filledArray[track-1]=null;
                if (colaux<ncols-1) filledArray[track+1]=null;
            }
            track=pbomb+ncols; // fila seguinte
            if (track<nrows) {
                filledArray[track]=null;
                if (colaux>0) filledArray[track-1]=null;
                if (colaux<ncols-1) filledArray[track+1]=null;
            }*/
            
            // Xeneramos de novo a táboa de posicións válidas
            fcellsIdx=0;
            for(int idx=0;idx<totcells;idx++) {
                if (filledArray[idx]!=null) {
                    trackArray[fcellsIdx]=filledArray[idx];
                    fcellsIdx++;
                }
            }
            tbombs++;
        }
        
        // Poñemos o resto de pezas. 
        // Cada cela debe ter un obxecto Piece distinto, xa que poden estar
        // en distintos estados e ter distintos valores. Calcula o valor de cada peza
        for(int row=0;row<nrows;row++) {
            for(int col=0;col<ncols;col++) {
                bomb=board.get(row,col);
                if (bomb==null) { // A cela está baleira
                    board.put(row,col,new MinesweeperPiece(getCellValue(row,col)));
                }
            }
        }
    }
    
    /**
     * Calcula o valor dunha cela segun as bombas que a rodean
     * @param row - Fila da cela
     * @param col - Columna da cela
     * @return - Valor da cela
     */
    private int getCellValue(int row, int col) throws Exception {
        int value=0;
        MinesweeperPiece p;
        
        // Miro a esquerda e dereita
        if (col>0) {
            p=(MinesweeperPiece)board.get(row,col-1);
            if ((p!=null)&&(p.isBomb())) value++;
        }
        if (col<ncols-1) {
            p=(MinesweeperPiece)board.get(row,col+1);
            if ((p!=null)&&(p.isBomb())) value++;                
        }
        // Fila de arriba
        if (row>0) {
            p=(MinesweeperPiece)board.get(row-1,col);
            if ((p!=null)&&(p.isBomb())) value++;
            if (col>0) {
                p=(MinesweeperPiece)board.get(row-1,col-1);
                if ((p!=null)&&(p.isBomb())) value++;
            }
            if (col<ncols-1) {
                p=(MinesweeperPiece)board.get(row-1,col+1);
                if ((p!=null)&&(p.isBomb())) value++;
            }
        }
        // Fila de abaixo
        if (row<nrows-1) {
            p=(MinesweeperPiece)board.get(row+1,col);
            if ((p!=null)&&(p.isBomb())) value++;
            if (col>0) {
                p=(MinesweeperPiece)board.get(row+1,col-1);
                if ((p!=null)&&(p.isBomb())) value++;
            }
            if (col<ncols-1) {
                p=(MinesweeperPiece)board.get(row+1,col+1);
                if ((p!=null)&&(p.isBomb())) value++;
            }
        }
        return value;
    }

    /**
     * Cambia o estado da celda da Position indicada a visible, e de todas as cercanas
     * que non son bombas...
     * @param m
     * @throws Exception 
     */
    private void discover(Position m) throws Exception {
        MinesweeperPiece p;
        int row=m.getRow();
        int column=m.getColumn();
        
        p=(MinesweeperPiece)board.get(row,column);
        if (p.isHidden()) {
            if (!p.isBomb()) {
                p.show();
                discovered++;
            }
            if (p.getValue()==0) {
                if (column>0) discover(new Position(row,column-1));
                if (column<ncols-1) discover(new Position(row,column+1));
        
                if (row>0) {
                    discover(new Position(row-1,column));
                    if (column>0) discover(new Position(row-1,column-1));
                    if (column<ncols-1) discover(new Position(row-1,column+1));
                }
                if (row<nrows-1) {
                    discover(new Position(row+1,column));
                    if (column>0) discover(new Position(row+1,column-1));
                    if (column<ncols-1) discover(new Position(row+1,column+1));
                }
            }
        }
    }

    /**
     * Pon visibles todas as fichas, para amosar o taboleiro ao rematar
     */
    private void discoverAll() {
        try {
            for(int row=0;row<nrows;row++) {
                for(int col=0;col<ncols;col++) {
                    ((MinesweeperPiece)board.get(row,col)).show();
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
