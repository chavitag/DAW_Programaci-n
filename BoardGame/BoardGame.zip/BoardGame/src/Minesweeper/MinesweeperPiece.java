/*
 * Copyright (C) 2018 xavi
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package Minesweeper;

import boardgames.Piece;

/**
 * Esta clase representa pezas do xogo
 * Son capaces de manter o estado de "ocultas" ou "visibles", amosando
 * imaxes distintas
 * @author xavi
 */
public class MinesweeperPiece extends Piece {
    private boolean hidden;
    private final String hiddenImage;

    /** Facemos tres constructores sobrecargados entre outras cousas como 
     * exemplo de sobrecarga de constructores. NON é necesario que o deseñedes
     * así... Este constructor é privado, porque non quero que se instancien
     * obxectos así, so é para uso dos outros constructores
     */
    private MinesweeperPiece() {
        // Non necesito chamar a super, porque a clase base ten un constructor
        // sen argumentos que se chama automáticamente
        name="";
        image=" ";
        value=0;
        hidden=true;    // Se crean "Ocultos"
        hiddenImage="X";
    }
    
    /**
     * CONSTRUCTOR. A partir do nome. Si o nome é "BOMB" crea unha bomba
     * Se non, crea unha peza normal
     * @param type 
     */
    public MinesweeperPiece(String type) {
        this(); // Chamamos ao constructor de arriba
        if (type.equals("BOMB")) {
            name="Bomb";
            image="*";
            value=100;
        } 
    }
    
    /**
     * CONSTRUCTOR: Crea unha peza indicando o seu valor. Si o valor é 100 é unha Bomba
     * @param value 
     */
    public MinesweeperPiece(int value) {
        this();
        this.value=value;
        if (value==100) {
            name="Bomb";
            image="*";
        } 
    }
    
    /**
     * Fai a peza visible
     */
    public void show() {
        hidden=false;
    }
    
    /**
     * Oculta a peza
     */
    public void hide() {
        hidden=true;
    }
    
    /**
     * Devolve true si a peza está oculta
     * @return 
     */
    public boolean isHidden() {
        return hidden;
    }
    
    /**
     * Devolve true si a peza é unha bomba
     * @return 
     */
    public boolean isBomb() {
        return (value==100);
    }
    
    /**
     * Devolve a presentación da peza tendo en conta o seu estado.
     * @return 
     */
    @Override
    public String toString() {
        if (hidden) return hiddenImage;
        if ((value==0)||(value==100)) return super.toString();
        return Integer.toString(value);
    }
    
}
