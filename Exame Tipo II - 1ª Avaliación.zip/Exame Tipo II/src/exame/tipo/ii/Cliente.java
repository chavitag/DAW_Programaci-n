/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exame.tipo.ii;

/**
 *
 * @author xavi
 */
public class Cliente {
    private String dni;
    private String nome;
    private String email;
    

    // Constructor. Si o DNI é erróneo lanza unha Exception notificando o fallo
    //
    public Cliente (String dni, String nome, String email) throws Exception  {
        if(!verificaDni(dni)) throw new Exception("Número de DNI Erróneo");
        this.dni = dni;          
        this.nome = nome;
        this.email= email;
    }

    public String getDni(){
        return this.dni;
    }
    
    public String getNome(){
        return this.nome;
    }
    
    public String getEmail(){
        return this.email;
    }
        
    // Sopreposición de toString. 
    @Override 
    public String toString() {
        return dni+" - "+nome+" ("+email+")";
        
    }

    /* Verifica que o DNI sexa correcto, devolve true ou false segundo o caso
    A facemos pública para que podamos chamala dende calqueira sitio que desexemos
    verificar un DNI, e estática, para que podamos chamala sen necesidade de instanciar
    un obxecto Cliente (pertence a TODOS os clientes, non a un cliente en particular).
    
    Evidentemente, si facedes o método "normal" e incluso privado, non é incorrecto pero
    a utilidade é diferente. Ver o exercicio 3 para ver as vantaxes de facelo así comparando
    coa forma de traballar no Exame Tipo I
    */
    public static boolean verificaDni(String num) throws Exception {
        char[] letras = {'T','R','W','A','G','M','Y','F','P','D','X','B','N','J','Z','S','Q','V','H','L','C','K','E'};
        char letra = num.charAt(num.length() - 1);
        String dni = num.substring(0, num.length() - 1);
        // parseInt pode producir unha NumberFormatException, pero ao ser unha
        // unchecked Exception non sería obrigatorio poñer o throws. O poñemos para 
        // indicar que ese erro sí importa...
        int numero = Integer.parseInt(dni); 
        int resto = numero % 23;
        return (letras[resto] == letra);
    }
    
}
