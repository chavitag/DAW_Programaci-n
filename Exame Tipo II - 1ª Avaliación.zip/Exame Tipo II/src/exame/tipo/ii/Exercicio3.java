/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exame.tipo.ii;

import java.util.Scanner;

/**
 *
 * @author xavi
 */
public class Exercicio3 {
      /**
     * Esta función é auxiliar para crear un cliente, este código é
     * estático para poder ser utilizado de xeito independente a creación
     * de obxectos da clase... 
     * Tamén é válido incluír este código directamente no main()
     */
    public static Cliente newClient() throws Exception {
        Cliente cliente;
        Scanner scn=new Scanner(System.in);
        System.out.println("\nCreación dun novo Cliente\n----------------------------------");
        System.out.println("DNI: ");
        String dni = scn.nextLine();
        // Deste xeito, si o DNI é incorrecto xa non continuamos pedindo o resto de datos...
        if (!Cliente.verificaDni(dni)) throw new Exception("DNI Erróneo");
        System.out.println("Nome: ");
        String nome = scn.nextLine();
        System.out.println("E-Mail: ");
        String email = scn.nextLine();
        cliente=new Cliente(dni,nome,email);
        return cliente;
    }
    
    
    public static void main(String[] args ) {
        String[] opciones={"Crear Cliente","Visualizar Cliente","Saír"};
        Menu menu=new Menu(opciones);
        Cliente cliente=null; 
        int opc;
      
        do {
            System.out.println("\n\n");  // Salto un par de liñas..
            opc=menu.choose();
            /*
                switch é unha instrucción que abrevia "if" cando se queren
                tratar distintos valores que pode tomar unha variable. O 
                código seguinte equivale a:
                    if (opc==1) {
                    } else if (opc==2) {
                      } ...
            */
            switch(opc) {
                case 1: 
                    try {
                        cliente=newClient();
                    } catch(Exception e) {
                        System.out.println("ERRO creando cliente: "+e.getMessage());
                    }
                    break;
                    
                case 2:
                    if (cliente!=null) System.out.println(cliente);
                    else System.out.println("Debes crear un cliente primeiro");
                    break;
            }
        } while(opc!=3);
    }
    
}
