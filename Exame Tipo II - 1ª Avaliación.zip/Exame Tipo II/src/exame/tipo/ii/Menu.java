/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exame.tipo.ii;

import java.util.Scanner;

/**
 *
 * @author xavi
 */
public class Menu {
    private String[] options;  // Opcións do menú
    
    public Menu(String[] options) {
        this.options=options;
    }
    
    public int choose() {
        Scanner scn=new Scanner(System.in);
        int opc;
        
        do {
            showOptions();
            System.out.print("\nElixe Opción: ");
            try { // Pode lanzar unha NumberFormatException...
                opc=Integer.parseInt(scn.nextLine());
            } catch(Exception e) {
                opc=0;  // Opción non válida... insistimos
            }
        } while((opc<1)||(opc>options.length));
        return opc;
    }
        
    private void showOptions() {
                       
        System.out.println("Menú\n-------------------------------------");
        for(int idx=1;idx<=options.length;idx++) {
            System.out.println(idx+".- "+options[idx-1]);
        }
    }
}
